# classifier.py — Rule-based page type classifier (fast, no API needed)

import re

# ── Keyword sets per page type ────────────────────────────────────────────────

RECIPE_SIGNALS = [
    "ingredients", "instructions", "method", "preparation", "serves", "servings",
    "prep time", "cook time", "total time", "tablespoon", "teaspoon", "cup of",
    "सामग्री", "विधि", "बनाने की विधि",          # Hindi
    "উপকরণ", "প্রণালী",                           # Bengali
    "పదార్థాలు", "తయారీ విధానం",                  # Telugu
    "பொருட்கள்", "செய்முறை",                       # Tamil
]

STORY_SIGNALS = [
    "memory", "memories", "childhood", "grandmother", "grandma", "nostalgia",
    "reminds me", "growing up", "my mother", "my father", "family recipe",
    "tradition", "festival", "celebration", "story", "tales",
    "याद", "दादी", "नानी", "बचपन", "परंपरा",      # Hindi
    "স্মৃতি", "দাদি", "ঐতিহ্য",                   # Bengali
]

EXPERIENCE_SIGNALS = [
    "i tried", "i ate", "i visited", "we had", "tasted", "first time",
    "experience", "journey", "travel", "trip", "street food", "market",
    "मैंने खाया", "मैंने चखा",                    # Hindi
]

REVIEW_SIGNALS = [
    "review", "rating", "stars", "recommend", "worth it", "must try",
    "overrated", "underrated", "ambiance", "service", "price", "value",
    "zomato", "swiggy", "yelp",
]

TRAVEL_SIGNALS = [
    "travel", "trip", "visited", "tour", "destination", "city", "state",
    "region", "local food", "street food", "food trail", "food walk",
]

SONG_SIGNALS = [
    "song", "lyrics", "geet", "bhajan", "folk song", "गीत", "भजन", "लोकगीत",
    "গান", "লোকগীত",
]


def _score(text_lower, signals):
    """Count how many signal phrases appear in the text."""
    return sum(1 for s in signals if s.lower() in text_lower)


def classify(raw_text, title=""):
    """
    Rule-based classifier.
    Returns one of: recipe / story / experience / review / travel / song / article / other
    """
    combined = (title + " " + raw_text).lower()

    scores = {
        "recipe":     _score(combined, RECIPE_SIGNALS),
        "story":      _score(combined, STORY_SIGNALS),
        "experience": _score(combined, EXPERIENCE_SIGNALS),
        "review":     _score(combined, REVIEW_SIGNALS),
        "travel":     _score(combined, TRAVEL_SIGNALS),
        "song":       _score(combined, SONG_SIGNALS),
    }

    best_type  = max(scores, key=scores.get)
    best_score = scores[best_type]

    if best_score == 0:
        return "article"   # food-related but no strong signal → generic article

    # Tie-break: recipe wins if tied (most structured, easiest to verify)
    if scores["recipe"] == best_score:
        return "recipe"

    return best_type


def classify_page(processed_page):
    """
    Wrapper: takes output of extractor.process_page() and adds page_type.
    Returns the same dict with 'page_type' added.
    """
    page_type = classify(
        processed_page.get("raw_text", ""),
        processed_page.get("title", "")
    )
    processed_page["page_type"] = page_type
    return processed_page
