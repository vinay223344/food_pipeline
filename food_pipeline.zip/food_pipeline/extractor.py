# extractor.py — Clean HTML → plain text + metadata + language detection

import re
from bs4 import BeautifulSoup
from langdetect import detect, LangDetectException
from config import FOOD_KEYWORDS


# Tags whose content we always strip (navigation, ads, etc.)
NOISE_TAGS = ["nav", "header", "footer", "aside", "script", "style",
              "noscript", "form", "button", "iframe", "figure"]


def clean_html(html):
    """Strip noise tags and return a BeautifulSoup object of the main content."""
    soup = BeautifulSoup(html, "lxml")

    for tag in soup(NOISE_TAGS):
        tag.decompose()

    # Try to find the main content block
    main = (
        soup.find("article") or
        soup.find("main") or
        soup.find(class_=re.compile(r"(post|entry|content|article|blog)", re.I)) or
        soup.find("body") or
        soup
    )
    return main


def extract_text(html):
    """Return clean plain text from raw HTML."""
    main = clean_html(html)
    text = main.get_text(separator="\n", strip=True)
    # Collapse excessive blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def extract_metadata(html, url):
    """Extract title, author, publish date from HTML."""
    soup = BeautifulSoup(html, "lxml")

    # Title
    title = ""
    og_title = soup.find("meta", property="og:title")
    if og_title and og_title.get("content"):
        title = og_title["content"]
    elif soup.find("title"):
        title = soup.find("title").get_text(strip=True)
    elif soup.find("h1"):
        title = soup.find("h1").get_text(strip=True)

    # Author
    author = ""
    author_meta = soup.find("meta", attrs={"name": "author"})
    if author_meta and author_meta.get("content"):
        author = author_meta["content"]
    else:
        author_tag = soup.find(class_=re.compile(r"author|byline", re.I))
        if author_tag:
            author = author_tag.get_text(strip=True)[:100]

    # Date
    date = ""
    date_meta = soup.find("meta", property="article:published_time")
    if date_meta and date_meta.get("content"):
        date = date_meta["content"]
    else:
        time_tag = soup.find("time")
        if time_tag:
            date = time_tag.get("datetime", "") or time_tag.get_text(strip=True)

    return {"title": title, "author": author, "date": date, "url": url}


def detect_language(text):
    """Detect language of text. Returns ISO 639-1 code or 'unknown'."""
    try:
        sample = text[:1000]  # langdetect works fine on a sample
        return detect(sample)
    except LangDetectException:
        return "unknown"


def is_food_related(text):
    """Quick keyword check — is this page about food at all?"""
    text_lower = text.lower()
    return any(kw.lower() in text_lower for kw in FOOD_KEYWORDS)


def process_page(page_dict):
    """
    Full extraction for one crawled page.
    Input : {url, html, title}
    Output: {url, title, author, date, raw_text, language, is_food}
    """
    html = page_dict["html"]
    url  = page_dict["url"]

    raw_text = extract_text(html)
    metadata = extract_metadata(html, url)
    language = detect_language(raw_text)
    food     = is_food_related(raw_text)

    return {
        "url":      url,
        "title":    metadata["title"] or page_dict.get("title", ""),
        "author":   metadata["author"],
        "date":     metadata["date"],
        "raw_text": raw_text,
        "language": language,
        "is_food":  food,
    }
