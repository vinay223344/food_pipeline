# config.py — Central configuration for the food data mining pipeline
# Sensitive values are loaded from .env — never hardcode secrets here.

import os
from dotenv import load_dotenv

load_dotenv()  # reads .env from the current working directory

# ── Crawler settings ──────────────────────────────────────────────────────────
CRAWL_DEPTH        = 3      # how many link-levels deep to follow from seed URL
MAX_PAGES          = 100    # safety cap: stop after this many pages per site
RATE_LIMIT_SECONDS = 1.5    # polite delay between requests (seconds)
REQUEST_TIMEOUT    = 15     # seconds before a request is abandoned

# Browser-like headers so sites don't block us
REQUEST_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

# ── URL skip rules — pages that are never food content ────────────────────────
SKIP_URL_PATTERNS = [
    "privacy", "privacy-policy", "terms", "terms-of-use", "terms-of-service",
    "disclaimer", "cookie", "sitemap", "contact", "contact-us",
    "advertise", "advertise-with-us", "about-us", "careers", "jobs",
    "login", "register", "signup", "sign-up", "account", "profile",
    "wp-login", "wp-admin", "wp-json", "feed", "rss",
    "newsletter", "subscribe", "unsubscribe",
    "404", "page-not-found",
]

# ── LLM settings ─────────────────────────────────────────────────────────────
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY", "")
MISTRAL_MODEL   = os.getenv("MISTRAL_MODEL", "mistral-small-latest")

if not MISTRAL_API_KEY:
    raise EnvironmentError(
        "MISTRAL_API_KEY not found. "
        "Create a .env file with MISTRAL_API_KEY=your_key"
    )

# ── LLM text truncation ───────────────────────────────────────────────────────
# Reduced from 3000 to avoid Mistral JSON truncation on long pages
LLM_MAX_CHARS         = 2000   # for non-recipe extraction
RECIPE_LLM_MAX_CHARS  = 3000   # recipes need more context for ingredients

# ── Storage settings ──────────────────────────────────────────────────────────
DB_PATH      = "data/food_data.db"          # SQLite
MONGO_URI    = os.getenv("MONGO_URI",    "mongodb://localhost:27017/")
MONGO_DB     = os.getenv("MONGO_DB_NAME","indian_food_db")

# ── Classification keywords (rule-based food filter) ─────────────────────────
FOOD_KEYWORDS = [
    # English
    "recipe", "food", "cook", "dish", "eat", "meal", "ingredient", "cuisine",
    "spice", "flavor", "taste", "kitchen", "restaurant", "street food", "snack",
    "breakfast", "lunch", "dinner", "dessert", "sweet", "curry", "rice", "bread",
    # Hindi
    "खाना", "रेसिपी", "खाद्य", "व्यंजन", "मसाला", "रोटी", "चावल", "दाल",
    # Bengali
    "রান্না", "খাবার", "রেসিপি", "মশলা",
    # Telugu
    "వంట", "ఆహారం", "రెసిపీ", "మసాలా",
    # Tamil
    "சமையல்", "உணவு", "ரெசிபி",
    # Marathi
    "जेवण", "रेसिपी", "खाद्यपदार्थ",
    # Gujarati
    "રસોઈ", "ખોરાક", "વ્યંજન",
]

# Page types the classifier can assign
PAGE_TYPES = ["recipe", "story", "experience", "review", "travel", "song", "article", "other"]
