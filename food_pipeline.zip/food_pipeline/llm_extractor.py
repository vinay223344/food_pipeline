# llm_extractor.py — Mistral-powered structured extraction for non-recipe content

import json
import re
import time
from mistralai import Mistral
from config import MISTRAL_API_KEY, MISTRAL_MODEL, LLM_MAX_CHARS

client = Mistral(api_key=MISTRAL_API_KEY)


SYSTEM_PROMPT = """You are an expert in Indian food culture, cuisine, and culinary history.
Your task is to analyze a piece of text about Indian food and extract structured information from it.
Always respond with valid JSON only — no markdown, no explanation, just the JSON object."""


EXTRACTION_PROMPT = """Analyze the following text about Indian food and extract the information below.

Text:
\"\"\"
{text}
\"\"\"

Return a JSON object with exactly these fields:
{{
  "food_items": ["list of specific food items, dishes, or ingredients mentioned"],
  "region_cuisine": "the Indian region or cuisine style this relates to (e.g. Bengali, Rajasthani, South Indian, Pakistani, etc.)",
  "occasion": "occasion or context if mentioned (e.g. festival, wedding, everyday meal, street food, etc.)",
  "emotions": "emotions or sentiments expressed about the food (e.g. nostalgia, joy, comfort, pride, etc.)",
  "key_snippets": ["2-3 most interesting or informative sentences from the text about food"],
  "language_of_origin": "the language this content was originally written in",
  "content_summary": "one sentence summary of what this text is about"
}}

Rules:
- food_items and key_snippets must be JSON arrays
- If a field has no relevant information, use an empty string "" or empty array []
- Do not add any fields beyond the ones listed above
- Respond with JSON only"""


def truncate_text(text, max_chars=None):
    """Keep text within token limits — take first + last chunk for context."""
    if max_chars is None:
        max_chars = LLM_MAX_CHARS
    if len(text) <= max_chars:
        return text
    half = max_chars // 2
    return text[:half] + "\n\n[...]\n\n" + text[-half:]


def extract_with_llm(page, retries=3, retry_delay=15):
    """
    Run Mistral extraction on a single page dict.
    Input : {id, url, page_type, language, raw_text, title, ...}
    Output: dict with extracted fields, or None on failure
    Retries on 429 rate-limit errors with exponential backoff.
    """
    raw_text = page.get("raw_text", "")
    if not raw_text or len(raw_text) < 100:
        print(f"  [LLM] Skipping {page['url']} — text too short")
        return None

    text_sample = truncate_text(raw_text)
    prompt = EXTRACTION_PROMPT.format(text=text_sample)

    for attempt in range(1, retries + 1):
        try:
            response = client.chat.complete(
                model=MISTRAL_MODEL,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user",   "content": prompt},
                ],
                temperature=0.1,   # low temp for consistent structured output
                max_tokens=800,
            )

            raw_output = response.choices[0].message.content.strip()

            # Strip markdown code fences if present
            if raw_output.startswith("```"):
                raw_output = re.sub(r"^```[a-z]*\n?", "", raw_output)
                raw_output = re.sub(r"\n?```$", "", raw_output).strip()

            extracted = json.loads(raw_output)

            # Ensure list fields are actually lists
            food_items   = extracted.get("food_items", [])
            key_snippets = extracted.get("key_snippets", [])
            if isinstance(food_items, str):
                food_items = [food_items]
            if isinstance(key_snippets, str):
                key_snippets = [key_snippets]

            return {
                "page_id":        page.get("id"),
                "url":            page["url"],
                "page_type":      page.get("page_type", "article"),
                "language":       page.get("language", "unknown"),
                "food_items":     food_items,
                "region_cuisine": extracted.get("region_cuisine", ""),
                "occasion":       extracted.get("occasion", ""),
                "emotions":       extracted.get("emotions", ""),
                "key_snippets":   key_snippets,
                "raw_llm_output": raw_output,
            }

        except json.JSONDecodeError as e:
            print(f"  [LLM] JSON parse error for {page['url']}: {e}")
            return None
        except Exception as e:
            err_str = str(e)
            if "429" in err_str or "capacity" in err_str.lower():
                wait = retry_delay * attempt
                print(f"  [LLM] Rate limited (attempt {attempt}/{retries}). Waiting {wait}s...")
                time.sleep(wait)
            else:
                print(f"  [LLM] API error for {page['url']}: {e}")
                return None

    print(f"  [LLM] All {retries} retries exhausted for {page['url']}")
    return None


def run_extraction_batch(pages):
    """
    Run LLM extraction on a list of pages.
    Returns list of extraction result dicts.
    """
    results = []
    total = len(pages)

    print(f"\n[LLM] Starting extraction on {total} pages...")

    for i, page in enumerate(pages, 1):
        print(f"  [{i}/{total}] {page['url'][:80]}")
        result = extract_with_llm(page)
        if result:
            results.append(result)
            print(f"         ✓ Extracted: {len(result['food_items'])} food items | "
                  f"region: {result['region_cuisine'] or 'unknown'}")
        else:
            print(f"         ✗ Skipped")

        # Polite delay between LLM calls to avoid rate limits
        if i < total:
            time.sleep(3)

    print(f"\n[LLM] Done. {len(results)}/{total} pages extracted successfully.")
    return results
