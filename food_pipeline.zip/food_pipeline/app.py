# app.py — Streamlit UI for the Indian Food Data Mining Pipeline

import streamlit as st
import threading
import queue
import json
import time
import sys
import os
from datetime import datetime
from urllib.parse import urlparse
from pymongo import MongoClient
from dotenv import load_dotenv

load_dotenv()

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Indian Food Pipeline",
    page_icon="🍛",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        color: #d4500a;
        margin-bottom: 0.2rem;
    }
    .sub-header {
        font-size: 1rem;
        color: #888;
        margin-bottom: 1.5rem;
    }
    .stat-card {
        background: #1e1e2e;
        border-radius: 10px;
        padding: 1rem 1.5rem;
        text-align: center;
        border: 1px solid #333;
    }
    .stat-number {
        font-size: 2rem;
        font-weight: 700;
        color: #f97316;
    }
    .stat-label {
        font-size: 0.85rem;
        color: #aaa;
    }
    .log-box {
        background: #0e0e0e;
        color: #00ff88;
        font-family: monospace;
        font-size: 0.8rem;
        padding: 1rem;
        border-radius: 8px;
        height: 320px;
        overflow-y: auto;
        border: 1px solid #333;
    }
    .badge-recipe     { background:#16a34a; color:white; padding:2px 8px; border-radius:12px; font-size:0.75rem; }
    .badge-story      { background:#7c3aed; color:white; padding:2px 8px; border-radius:12px; font-size:0.75rem; }
    .badge-experience { background:#0284c7; color:white; padding:2px 8px; border-radius:12px; font-size:0.75rem; }
    .badge-review     { background:#b45309; color:white; padding:2px 8px; border-radius:12px; font-size:0.75rem; }
    .badge-article    { background:#475569; color:white; padding:2px 8px; border-radius:12px; font-size:0.75rem; }
    .badge-other      { background:#374151; color:white; padding:2px 8px; border-radius:12px; font-size:0.75rem; }
</style>
""", unsafe_allow_html=True)


# ── MongoDB helper ────────────────────────────────────────────────────────────
@st.cache_resource
def get_mongo():
    uri    = os.getenv("MONGO_URI",     "mongodb://localhost:27017/")
    db_name= os.getenv("MONGO_DB_NAME", "indian_food_db")
    client = MongoClient(uri)
    return client[db_name]


def get_db_stats():
    db = get_mongo()
    pages    = db.pages.count_documents({})
    recipes  = db.recipes.count_documents({})
    extracts = db.extracts.count_documents({})
    sites    = len(db.pages.distinct("source_site"))
    langs    = len(db.pages.distinct("language"))
    return pages, recipes, extracts, sites, langs


def get_type_breakdown():
    db = get_mongo()
    pipeline = [
        {"$group": {"_id": "$page_type", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
    ]
    return list(db.pages.aggregate(pipeline))


def get_recent_recipes(limit=10):
    db = get_mongo()
    return list(db.recipes.find({}, {
        "dish_name":1, "cuisine":1, "url":1,
        "ingredients":1, "method":1, "cook_time":1,
        "servings":1, "extraction_source":1
    }).sort("extracted_at", -1).limit(limit))


def get_recent_extracts(limit=10):
    db = get_mongo()
    return list(db.extracts.find({}, {
        "url":1, "page_type":1, "language":1,
        "food_items":1, "region_cuisine":1,
        "emotions":1, "occasion":1, "key_snippets":1
    }).sort("extracted_at", -1).limit(limit))


def get_recent_pages(limit=20):
    db = get_mongo()
    return list(db.pages.find({}, {
        "url":1, "title":1, "page_type":1,
        "language":1, "source_site":1, "crawled_at":1
    }).sort("crawled_at", -1).limit(limit))


# ── Pipeline runner (in background thread) ───────────────────────────────────
# NOTE: Do NOT put log_queue here as a module-level variable.
# It must live in st.session_state so it survives st.rerun() calls.

class StreamlitLogger:
    """Redirect stdout to both terminal and the log queue."""
    def __init__(self, q):
        self.q = q
        self.terminal = sys.__stdout__

    def write(self, msg):
        if msg.strip():
            self.q.put(msg.strip())
        self.terminal.write(msg)

    def flush(self):
        self.terminal.flush()


def run_pipeline_thread(url, depth, run_llm, q):
    """Run the pipeline in a background thread, capturing logs."""
    old_stdout = sys.stdout
    sys.stdout = StreamlitLogger(q)
    try:
        from crawler          import crawl
        from extractor        import process_page
        from classifier       import classify_page
        from llm_extractor    import run_extraction_batch
        from recipe_extractor import run_recipe_extraction_batch
        import storage_mongo as store

        store.init_db()
        site_name = urlparse(url).netloc

        q.put(f"🚀 Starting pipeline for: {url}")
        q.put(f"   Depth: {depth} | LLM: {'ON' if run_llm else 'OFF'}")

        # Stage 1
        q.put("__STAGE__Crawling pages...")
        pages = crawl(url, depth=depth)
        q.put(f"✓ Crawled {len(pages)} pages")

        if not pages:
            q.put("❌ No pages found. Check the URL.")
            q.put("__DONE__")
            return

        # Stage 2+3
        q.put("__STAGE__Extracting text & classifying...")
        processed = []
        for i, page in enumerate(pages):
            p = process_page(page)
            if not p["is_food"]:
                continue
            p = classify_page(p)
            processed.append(p)
            db_id = store.save_page(
                url=p["url"], title=p["title"], raw_text=p["raw_text"],
                language=p["language"], page_type=p["page_type"], source_site=site_name,
            )
            p["id"] = db_id
            q.put(f"__PROGRESS__{i+1}/{len(pages)}")

        q.put(f"✓ {len(processed)} food-related pages saved")

        if run_llm:
            # Stage 4a: Recipes
            recipe_pages = [p for p in processed if p["page_type"] == "recipe"]
            q.put(f"__STAGE__Extracting {len(recipe_pages)} recipes...")
            html_map = {pg["url"].rstrip("/"): pg["html"] for pg in pages}
            for p in recipe_pages:
                p["html"] = html_map.get(p["url"].rstrip("/"), "")

            recipe_results = run_recipe_extraction_batch(recipe_pages)
            for page, recipe in recipe_results:
                store.save_recipe(
                    page_id=page.get("id"), url=page["url"],
                    source_site=site_name, language=page.get("language", "unknown"),
                    recipe_data=recipe,
                )
            q.put(f"✓ {len(recipe_results)} recipes extracted & saved")

            # Stage 4b: Non-recipe
            non_recipe = [p for p in processed if p["page_type"] not in ("recipe", "other")]
            q.put(f"__STAGE__LLM extraction on {len(non_recipe)} non-recipe pages...")
            if non_recipe:
                results = run_extraction_batch(non_recipe)
                for r in results:
                    store.save_extract(
                        page_id=r["page_id"], url=r["url"],
                        page_type=r["page_type"], language=r["language"],
                        food_items=r["food_items"], region_cuisine=r["region_cuisine"],
                        occasion=r["occasion"], emotions=r["emotions"],
                        key_snippets=r["key_snippets"], raw_llm_output=r["raw_llm_output"],
                    )
                q.put(f"✓ {len(results)} non-recipe extracts saved")
            else:
                q.put("  No non-recipe pages to extract.")

        q.put("__STAGE__Done!")
        q.put("✅ Pipeline complete!")
        q.put("__DONE__")

    except Exception as e:
        import traceback
        q.put(f"❌ Error: {e}")
        q.put(traceback.format_exc())
        q.put("__DONE__")
    finally:
        sys.stdout = old_stdout


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Pipeline Settings")
    st.markdown("---")

    url_input = st.text_input(
        "🌐 Seed URL",
        placeholder="https://example.com/recipes/",
        help="The starting URL to crawl"
    )

    depth_input = st.slider(
        "🔁 Crawl Depth",
        min_value=1, max_value=10, value=2,
        help="How many link-levels deep to follow. Higher = more pages, more time."
    )

    max_pages_input = st.number_input(
        "📄 Max Pages",
        min_value=10, max_value=10000, value=100, step=10,
        help="Safety cap on total pages crawled per run"
    )

    run_llm_input = st.toggle("🤖 Enable LLM Extraction", value=True,
        help="Use Mistral to extract structured data. Disable for crawl-only mode.")

    st.markdown("---")
    st.markdown("**LLM Model:** `mistral-small-latest`")
    st.markdown("**Database:** MongoDB `indian_food_db`")
    st.markdown("---")

    run_btn = st.button("▶ Run Pipeline", type="primary", use_container_width=True)
    clear_btn = st.button("🗑 Clear Logs", use_container_width=True)


# ── Main area ─────────────────────────────────────────────────────────────────
st.markdown('<div class="main-header">🍛 Indian Food Data Mining Pipeline</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Crawl · Extract · Classify · Store</div>', unsafe_allow_html=True)

# ── Stats row ─────────────────────────────────────────────────────────────────
pages_count, recipes_count, extracts_count, sites_count, langs_count = get_db_stats()

c1, c2, c3, c4, c5 = st.columns(5)
with c1:
    st.metric("📄 Pages Crawled",  pages_count)
with c2:
    st.metric("🍽 Recipes Mined",  recipes_count)
with c3:
    st.metric("📖 Extracts",       extracts_count)
with c4:
    st.metric("🌐 Sites",          sites_count)
with c5:
    st.metric("🗣 Languages",      langs_count)

col_refresh, _ = st.columns([1, 5])
with col_refresh:
    if st.button("🔄 Refresh Stats"):
        st.cache_resource.clear()
        st.rerun()

st.markdown("---")

# ── Tabs ──────────────────────────────────────────────────────────────────────
tab_run, tab_recipes, tab_extracts, tab_pages, tab_explore = st.tabs([
    "▶ Run Pipeline",
    "🍽 Recipes",
    "📖 Extracts",
    "📄 All Pages",
    "🔍 Explore",
])


# ── Tab 1: Run Pipeline ───────────────────────────────────────────────────────
with tab_run:
    st.markdown("### Run the pipeline on a new URL")
    st.info("Configure settings in the sidebar, then click **▶ Run Pipeline**.")

    # ── Initialize session state ──────────────────────────────────────────────
    # The queue MUST live in session_state — module-level variables are
    # recreated on every st.rerun(), which disconnects them from the thread.
    if "log_queue" not in st.session_state:
        st.session_state.log_queue = queue.Queue()
    if "logs" not in st.session_state:
        st.session_state.logs = []
    if "running" not in st.session_state:
        st.session_state.running = False
    if "current_stage" not in st.session_state:
        st.session_state.current_stage = ""
    if "progress" not in st.session_state:
        st.session_state.progress = 0
    if "progress_total" not in st.session_state:
        st.session_state.progress_total = 1

    # Use the persistent queue from session_state
    q = st.session_state.log_queue

    if clear_btn:
        st.session_state.logs = []
        st.session_state.current_stage = ""
        st.session_state.progress = 0

    if run_btn:
        if not url_input:
            st.error("Please enter a URL in the sidebar.")
        elif st.session_state.running:
            st.warning("Pipeline is already running.")
        else:
            # Reset state for new run
            st.session_state.logs = []
            st.session_state.running = True
            st.session_state.current_stage = "Starting..."
            st.session_state.progress = 0
            st.session_state.progress_total = 1
            # Fresh queue for this run
            st.session_state.log_queue = queue.Queue()
            q = st.session_state.log_queue

            import config
            config.MAX_PAGES = max_pages_input

            t = threading.Thread(
                target=run_pipeline_thread,
                args=(url_input, depth_input, run_llm_input, q),
                daemon=True,
            )
            t.start()

    # ── Drain the queue into session state ────────────────────────────────────
    while not q.empty():
        msg = q.get_nowait()
        if msg == "__DONE__":
            st.session_state.running = False
            st.session_state.progress = st.session_state.progress_total
        elif msg.startswith("__STAGE__"):
            st.session_state.current_stage = msg.replace("__STAGE__", "")
        elif msg.startswith("__PROGRESS__"):
            parts = msg.replace("__PROGRESS__", "").split("/")
            if len(parts) == 2:
                st.session_state.progress       = int(parts[0])
                st.session_state.progress_total = int(parts[1])
        else:
            st.session_state.logs.append(msg)

    # ── Status + progress bar ─────────────────────────────────────────────────
    if st.session_state.running:
        st.warning(f"⏳ **{st.session_state.current_stage}**")
        total = max(st.session_state.progress_total, 1)
        pct   = st.session_state.progress / total
        st.progress(pct, text=f"Page {st.session_state.progress} of {total}")
    elif st.session_state.logs:
        last = "\n".join(st.session_state.logs[-3:])
        if "complete" in last.lower():
            st.success("✅ Pipeline completed successfully!")
        elif "❌" in last or "error" in last.lower():
            st.error("❌ Pipeline encountered an error. See log below.")

    # ── Log display ───────────────────────────────────────────────────────────
    if st.session_state.logs:
        st.code("\n".join(st.session_state.logs), language=None)

    # ── Run summary ───────────────────────────────────────────────────────────
    if not st.session_state.running and st.session_state.logs:
        log_text = "\n".join(st.session_state.logs)
        crawled  = log_text.count("depth=")
        saved    = log_text.count("[SAVED]")
        recipes  = log_text.count("[library]") + log_text.count("[llm]")
        extracts = log_text.count("Extracted:")
        with st.expander("📊 Run Summary", expanded=True):
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Pages Crawled", crawled)
            c2.metric("Pages Saved",   saved)
            c3.metric("Recipes",       recipes)
            c4.metric("Extracts",      extracts)

    # ── AUTO-REFRESH: rerun every 1.5s while pipeline is running ─────────────
    if st.session_state.running:
        time.sleep(1.5)
        st.rerun()


# ── Tab 2: Recipes ────────────────────────────────────────────────────────────
with tab_recipes:
    st.markdown("### Extracted Recipes")

    db = get_mongo()

    # Filters
    col1, col2, col3 = st.columns(3)
    with col1:
        search_dish = st.text_input("🔍 Search dish name", key="recipe_search")
    with col2:
        all_cuisines = ["All"] + sorted(db.recipes.distinct("cuisine"))
        cuisine_filter = st.selectbox("Cuisine", all_cuisines, key="cuisine_filter")
    with col3:
        all_sites = ["All"] + sorted(db.recipes.distinct("source_site"))
        site_filter = st.selectbox("Source Site", all_sites, key="recipe_site_filter")

    # Build query
    query = {}
    if search_dish:
        query["dish_name"] = {"$regex": search_dish, "$options": "i"}
    if cuisine_filter != "All":
        query["cuisine"] = cuisine_filter
    if site_filter != "All":
        query["source_site"] = site_filter

    recipes = list(db.recipes.find(query).sort("extracted_at", -1).limit(50))
    st.markdown(f"Showing **{len(recipes)}** recipes")

    for r in recipes:
        with st.expander(f"🍽 {r.get('dish_name', 'Unknown')}  —  {r.get('cuisine', '')}  |  {r.get('source_site', '')}"):
            c1, c2 = st.columns([1, 2])
            with c1:
                st.markdown(f"**Cuisine:** {r.get('cuisine', '—')}")
                st.markdown(f"**Region:** {r.get('region', '—')}")
                st.markdown(f"**Servings:** {r.get('servings', '—')}")
                st.markdown(f"**Prep time:** {r.get('prep_time', '—')} min")
                st.markdown(f"**Cook time:** {r.get('cook_time', '—')} min")
                st.markdown(f"**Dietary:** {r.get('dietary', '—')}")
                st.markdown(f"**Extracted by:** `{r.get('extraction_source', '—')}`")
                st.markdown(f"[🔗 Source URL]({r.get('url', '#')})")
            with c2:
                st.markdown("**Ingredients:**")
                for ing in r.get("ingredients", []):
                    item = ing.get("item", ing) if isinstance(ing, dict) else ing
                    st.markdown(f"- {item}")
                st.markdown("**Method:**")
                for i, step in enumerate(r.get("method", []), 1):
                    st.markdown(f"{i}. {step}")


# ── Tab 3: Extracts (non-recipe) ──────────────────────────────────────────────
with tab_extracts:
    st.markdown("### Non-Recipe Extracts (Stories, Experiences, Reviews)")

    col1, col2 = st.columns(2)
    with col1:
        type_options = ["All", "story", "experience", "review", "travel", "article"]
        type_filter = st.selectbox("Page Type", type_options, key="extract_type")
    with col2:
        lang_options = ["All"] + sorted(db.extracts.distinct("language"))
        lang_filter = st.selectbox("Language", lang_options, key="extract_lang")

    query = {}
    if type_filter != "All":
        query["page_type"] = type_filter
    if lang_filter != "All":
        query["language"] = lang_filter

    extracts = list(db.extracts.find(query).sort("extracted_at", -1).limit(50))
    st.markdown(f"Showing **{len(extracts)}** extracts")

    for e in extracts:
        food_items = e.get("food_items", [])
        if isinstance(food_items, str):
            try:
                food_items = json.loads(food_items)
            except Exception:
                food_items = []

        label = f"📖 [{e.get('page_type','?').upper()}]  {e.get('url','')[:70]}"
        with st.expander(label):
            c1, c2 = st.columns([1, 2])
            with c1:
                st.markdown(f"**Type:** {e.get('page_type', '—')}")
                st.markdown(f"**Language:** {e.get('language', '—')}")
                st.markdown(f"**Region:** {e.get('region_cuisine', '—')}")
                st.markdown(f"**Occasion:** {e.get('occasion', '—')}")
                st.markdown(f"**Emotions:** {e.get('emotions', '—')}")
                st.markdown(f"[🔗 Source URL]({e.get('url', '#')})")
            with c2:
                st.markdown("**Food Items Mentioned:**")
                if food_items:
                    st.markdown(", ".join(f"`{f}`" for f in food_items[:20]))
                else:
                    st.markdown("—")
                st.markdown("**Key Snippets:**")
                snippets = e.get("key_snippets", [])
                if isinstance(snippets, str):
                    try:
                        snippets = json.loads(snippets)
                    except Exception:
                        snippets = []
                for s in snippets:
                    st.markdown(f"> {s}")


# ── Tab 4: All Pages ──────────────────────────────────────────────────────────
with tab_pages:
    st.markdown("### All Crawled Pages")

    col1, col2, col3 = st.columns(3)
    with col1:
        page_type_opts = ["All"] + sorted(db.pages.distinct("page_type"))
        page_type_filter = st.selectbox("Type", page_type_opts, key="page_type_f")
    with col2:
        page_site_opts = ["All"] + sorted(db.pages.distinct("source_site"))
        page_site_filter = st.selectbox("Site", page_site_opts, key="page_site_f")
    with col3:
        page_lang_opts = ["All"] + sorted(db.pages.distinct("language"))
        page_lang_filter = st.selectbox("Language", page_lang_opts, key="page_lang_f")

    query = {}
    if page_type_filter != "All":
        query["page_type"] = page_type_filter
    if page_site_filter != "All":
        query["source_site"] = page_site_filter
    if page_lang_filter != "All":
        query["language"] = page_lang_filter

    pages_data = list(db.pages.find(query, {
        "url":1, "title":1, "page_type":1, "language":1,
        "source_site":1, "crawled_at":1
    }).sort("crawled_at", -1).limit(100))

    st.markdown(f"Showing **{len(pages_data)}** pages")

    # Table view
    import pandas as pd
    if pages_data:
        df = pd.DataFrame([{
            "Title":       p.get("title", "")[:60],
            "Type":        p.get("page_type", ""),
            "Language":    p.get("language", ""),
            "Site":        p.get("source_site", ""),
            "URL":         p.get("url", ""),
            "Crawled At":  str(p.get("crawled_at", ""))[:19],
        } for p in pages_data])
        st.dataframe(df, use_container_width=True, hide_index=True)


# ── Tab 5: Explore ────────────────────────────────────────────────────────────
with tab_explore:
    st.markdown("### Explore the Data")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("#### Page Type Breakdown")
        breakdown = get_type_breakdown()
        if breakdown:
            import pandas as pd
            df_types = pd.DataFrame(breakdown).rename(columns={"_id": "Type", "count": "Count"})
            st.bar_chart(df_types.set_index("Type"))

    with col2:
        st.markdown("#### Top Food Items (from Extracts)")
        pipeline = [
            {"$unwind": "$food_items"},
            {"$group": {"_id": "$food_items", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
            {"$limit": 20},
        ]
        top_foods = list(db.extracts.aggregate(pipeline))
        if top_foods:
            df_foods = pd.DataFrame(top_foods).rename(columns={"_id": "Food Item", "count": "Mentions"})
            st.dataframe(df_foods, use_container_width=True, hide_index=True)
        else:
            st.info("No extract data yet. Run the pipeline first.")

    st.markdown("#### Top Cuisines (from Recipes)")
    pipeline2 = [
        {"$match": {"cuisine": {"$ne": ""}}},
        {"$group": {"_id": "$cuisine", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {"$limit": 15},
    ]
    top_cuisines = list(db.recipes.aggregate(pipeline2))
    if top_cuisines:
        df_cuisines = pd.DataFrame(top_cuisines).rename(columns={"_id": "Cuisine", "count": "Recipes"})
        st.bar_chart(df_cuisines.set_index("Cuisine"))
    else:
        st.info("No recipe data yet.")

    st.markdown("#### Export Data")
    col1, col2 = st.columns(2)
    with col1:
        if st.button("📥 Export Recipes to JSON"):
            recipes_all = list(db.recipes.find({}, {"_id": 0}))
            st.download_button(
                label="⬇ Download recipes.json",
                data=json.dumps(recipes_all, indent=2, default=str),
                file_name="recipes.json",
                mime="application/json",
            )
    with col2:
        if st.button("📥 Export Extracts to JSON"):
            extracts_all = list(db.extracts.find({}, {"_id": 0}))
            st.download_button(
                label="⬇ Download extracts.json",
                data=json.dumps(extracts_all, indent=2, default=str),
                file_name="extracts.json",
                mime="application/json",
            )
