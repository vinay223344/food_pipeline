# storage_mongo.py — MongoDB storage layer for the food data mining pipeline
#
# Collections:
#   pages    — every crawled page (raw text + metadata)
#   extracts — LLM-extracted structured data

import json
from datetime import datetime, timezone
from pymongo import MongoClient, ASCENDING
from pymongo.errors import DuplicateKeyError
from config import MONGO_URI, MONGO_DB

# ── Connection ────────────────────────────────────────────────────────────────
DB_NAME = MONGO_DB

_client = None
_db     = None


def get_db():
    """Return the MongoDB database, creating the connection once."""
    global _client, _db
    if _db is None:
        _client = MongoClient(MONGO_URI)
        _db     = _client[DB_NAME]
    return _db


def init_db():
    """Create indexes for fast lookups and deduplication."""
    db = get_db()

    # pages: unique index on url for deduplication
    db.pages.create_index([("url", ASCENDING)], unique=True)
    db.pages.create_index([("source_site", ASCENDING)])
    db.pages.create_index([("page_type", ASCENDING)])
    db.pages.create_index([("language", ASCENDING)])

    # extracts: index on url and page_id
    db.extracts.create_index([("url", ASCENDING)])
    db.extracts.create_index([("page_id", ASCENDING)])
    db.extracts.create_index([("region_cuisine", ASCENDING)])
    db.extracts.create_index([("page_type", ASCENDING)])

    # recipes collection
    db.recipes.create_index([("url", ASCENDING)], unique=True)
    db.recipes.create_index([("cuisine", ASCENDING)])
    db.recipes.create_index([("region", ASCENDING)])
    db.recipes.create_index([("dish_name", ASCENDING)])
    db.recipes.create_index([("source_site", ASCENDING)])

    print(f"[MongoDB] Connected to '{DB_NAME}'. Indexes ready.")


# ── Pages ─────────────────────────────────────────────────────────────────────

def save_page(url, title, raw_text, language, page_type, source_site):
    """
    Insert a crawled page. Skips silently if URL already exists.
    Returns the inserted/existing document _id.
    """
    db = get_db()
    doc = {
        "url":         url,
        "title":       title,
        "raw_text":    raw_text,
        "language":    language,
        "page_type":   page_type,
        "source_site": source_site,
        "crawled_at":  datetime.now(timezone.utc),
    }
    try:
        result = db.pages.insert_one(doc)
        return result.inserted_id
    except DuplicateKeyError:
        # Already exists — return existing _id
        existing = db.pages.find_one({"url": url}, {"_id": 1})
        return existing["_id"] if existing else None
    except Exception as e:
        print(f"[MongoDB] Error saving page {url}: {e}")
        return None


def get_page_id(url):
    """Return the _id of a page by URL."""
    db = get_db()
    doc = db.pages.find_one({"url": url}, {"_id": 1})
    return doc["_id"] if doc else None


# ── Extracts ──────────────────────────────────────────────────────────────────

def save_extract(page_id, url, page_type, language, food_items,
                 region_cuisine, occasion, emotions, key_snippets, raw_llm_output):
    """
    Save LLM extraction result.
    food_items and key_snippets are stored as native arrays (MongoDB handles lists natively).
    """
    db = get_db()

    # Normalize list fields — accept both list and JSON string
    def to_list(val):
        if isinstance(val, list):
            return val
        if isinstance(val, str):
            try:
                parsed = json.loads(val)
                return parsed if isinstance(parsed, list) else [parsed]
            except Exception:
                return [val] if val else []
        return []

    # Normalize scalar fields — accept both str and list
    def to_str(val):
        if isinstance(val, str):
            return val
        if isinstance(val, list):
            return ", ".join(str(v) for v in val)
        return str(val) if val else ""

    doc = {
        "page_id":        page_id,
        "url":            url,
        "page_type":      page_type,
        "language":       language,
        "food_items":     to_list(food_items),      # native array
        "region_cuisine": to_str(region_cuisine),
        "occasion":       to_str(occasion),
        "emotions":       to_str(emotions),
        "key_snippets":   to_list(key_snippets),    # native array
        "raw_llm_output": raw_llm_output,
        "extracted_at":   datetime.now(timezone.utc),
    }

    try:
        result = db.extracts.insert_one(doc)
        return result.inserted_id
    except Exception as e:
        print(f"[MongoDB] Error saving extract for {url}: {e}")
        return None


# ── Queries ───────────────────────────────────────────────────────────────────

# ── Recipes ───────────────────────────────────────────────────────────────────

def save_recipe(page_id, url, source_site, language, recipe_data):
    """
    Save a structured recipe document.
    recipe_data is the dict returned by recipe_extractor.extract_recipe()
    """
    db = get_db()
    doc = {
        "page_id":     page_id,
        "url":         url,
        "source_site": source_site,
        "language":    language,
        "dish_name":   recipe_data.get("dish_name", ""),
        "description": recipe_data.get("description", ""),
        "cuisine":     recipe_data.get("cuisine", ""),
        "region":      recipe_data.get("region", ""),
        "ingredients": recipe_data.get("ingredients", []),   # native array of dicts
        "method":      recipe_data.get("method", []),        # native array of strings
        "servings":    recipe_data.get("servings", ""),
        "prep_time":   recipe_data.get("prep_time", ""),
        "cook_time":   recipe_data.get("cook_time", ""),
        "total_time":  recipe_data.get("total_time", ""),
        "occasion":    recipe_data.get("occasion", ""),
        "dietary":     recipe_data.get("dietary", ""),
        "language_of_origin": recipe_data.get("language_of_origin", language),
        "extraction_source":  recipe_data.get("source", "unknown"),  # 'recipe-scrapers' or 'llm'
        "extracted_at": datetime.now(timezone.utc),
    }
    try:
        result = db.recipes.insert_one(doc)
        return result.inserted_id
    except DuplicateKeyError:
        print(f"  [MongoDB] Recipe already exists: {url}")
        return None
    except Exception as e:
        print(f"  [MongoDB] Error saving recipe for {url}: {e}")
        return None


def get_unextracted_pages():
    """
    Return pages that haven't been through LLM extraction yet,
    are not recipes/other, and have enough text.
    """
    db = get_db()

    # Get URLs already extracted
    extracted_urls = set(db.extracts.distinct("url"))

    cursor = db.pages.find({
        "url":       {"$nin": list(extracted_urls)},
        "page_type": {"$nin": ["recipe", "other"]},
        "$expr":     {"$gt": [{"$strLenCP": {"$ifNull": ["$raw_text", ""]}}, 200]},
    })
    return list(cursor)


def export_to_csv(output_path="data/extracts_export_mongo.csv"):
    """Export all extracts to a CSV file."""
    import csv
    db = get_db()

    pipeline = [
        {
            "$lookup": {
                "from":         "pages",
                "localField":   "page_id",
                "foreignField": "_id",
                "as":           "page_info",
            }
        },
        {"$unwind": {"path": "$page_info", "preserveNullAndEmptyArrays": True}},
        {
            "$project": {
                "url":            1,
                "page_type":      1,
                "language":       1,
                "food_items":     1,
                "region_cuisine": 1,
                "occasion":       1,
                "emotions":       1,
                "key_snippets":   1,
                "title":          "$page_info.title",
                "source_site":    "$page_info.source_site",
            }
        },
    ]

    rows = list(db.extracts.aggregate(pipeline))

    if not rows:
        print("[MongoDB Export] No extracts to export yet.")
        return

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["url", "page_type", "language", "food_items",
                         "region_cuisine", "occasion", "emotions",
                         "key_snippets", "title", "source_site"])
        for row in rows:
            writer.writerow([
                row.get("url", ""),
                row.get("page_type", ""),
                row.get("language", ""),
                json.dumps(row.get("food_items", []), ensure_ascii=False),
                row.get("region_cuisine", ""),
                row.get("occasion", ""),
                row.get("emotions", ""),
                json.dumps(row.get("key_snippets", []), ensure_ascii=False),
                row.get("title", ""),
                row.get("source_site", ""),
            ])

    print(f"[MongoDB Export] Saved {len(rows)} rows to {output_path}")


def get_stats():
    """Print a quick summary of what's in MongoDB."""
    db = get_db()

    total_pages    = db.pages.count_documents({})
    total_extracts = db.extracts.count_documents({})
    total_recipes  = db.recipes.count_documents({})

    type_counts = db.pages.aggregate([
        {"$group": {"_id": "$page_type", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
    ])

    print(f"\n{'='*40}")
    print(f"  Database        : {DB_NAME} (MongoDB)")
    print(f"  Pages crawled   : {total_pages}")
    print(f"  LLM extracts    : {total_extracts}")
    print(f"  Recipes mined   : {total_recipes}")
    print(f"  Breakdown by type:")
    for doc in type_counts:
        print(f"    {doc['_id']:15s}: {doc['count']}")
    print(f"{'='*40}\n")
