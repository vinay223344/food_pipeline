# storage.py — SQLite database layer

import sqlite3
import json
import csv
import os
from config import DB_PATH


def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create tables if they don't exist."""
    conn = get_connection()
    cur = conn.cursor()

    # Raw crawled pages
    cur.execute("""
        CREATE TABLE IF NOT EXISTS pages (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            url         TEXT    UNIQUE NOT NULL,
            title       TEXT,
            raw_text    TEXT,
            language    TEXT,
            page_type   TEXT,
            crawled_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            source_site TEXT
        )
    """)

    # LLM-extracted structured data for non-recipe pages
    cur.execute("""
        CREATE TABLE IF NOT EXISTS extracts (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            page_id         INTEGER REFERENCES pages(id),
            url             TEXT,
            page_type       TEXT,
            language        TEXT,
            food_items      TEXT,   -- JSON array
            region_cuisine  TEXT,
            occasion        TEXT,
            emotions        TEXT,
            key_snippets    TEXT,   -- JSON array
            raw_llm_output  TEXT,
            extracted_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Structured recipe data
    cur.execute("""
        CREATE TABLE IF NOT EXISTS recipes (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            page_id             INTEGER REFERENCES pages(id),
            url                 TEXT    UNIQUE,
            source_site         TEXT,
            language            TEXT,
            dish_name           TEXT,
            description         TEXT,
            cuisine             TEXT,
            region              TEXT,
            ingredients         TEXT,   -- JSON array of dicts
            method              TEXT,   -- JSON array of strings
            servings            TEXT,
            prep_time           TEXT,
            cook_time           TEXT,
            total_time          TEXT,
            occasion            TEXT,
            dietary             TEXT,
            language_of_origin  TEXT,
            extraction_source   TEXT,
            extracted_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()
    print("[DB] Tables ready.")


def save_page(url, title, raw_text, language, page_type, source_site):
    """Insert a crawled page; skip if URL already exists. Returns the page id."""
    conn = get_connection()
    cur = conn.cursor()
    try:
        cur.execute("""
            INSERT OR IGNORE INTO pages (url, title, raw_text, language, page_type, source_site)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (url, title, raw_text, language, page_type, source_site))
        conn.commit()
        # Get the id whether it was just inserted or already existed
        cur.execute("SELECT id FROM pages WHERE url = ?", (url,))
        row = cur.fetchone()
        page_id = row["id"] if row else None
    except Exception as e:
        print(f"[DB] Error saving page {url}: {e}")
        page_id = None
    finally:
        conn.close()
    return page_id


def save_extract(page_id, url, page_type, language, food_items,
                 region_cuisine, occasion, emotions, key_snippets, raw_llm_output):
    """Save LLM extraction result."""
    conn = get_connection()
    cur = conn.cursor()
    try:
        # Ensure list fields are serialized to JSON strings
        # Defensive: handle any unexpected types from LLM output
        def to_json_str(val):
            if isinstance(val, str):
                return val  # already a string (maybe already serialized)
            try:
                return json.dumps(val, ensure_ascii=False)
            except Exception:
                return json.dumps([str(val)], ensure_ascii=False)

        food_items    = to_json_str(food_items)
        key_snippets  = to_json_str(key_snippets)
        # Also coerce scalar fields that LLM might return as lists
        region_cuisine = to_json_str(region_cuisine) if not isinstance(region_cuisine, str) else region_cuisine
        occasion       = to_json_str(occasion)       if not isinstance(occasion, str)       else occasion
        emotions       = to_json_str(emotions)       if not isinstance(emotions, str)        else emotions
        raw_llm_output = to_json_str(raw_llm_output) if not isinstance(raw_llm_output, str) else raw_llm_output

        cur.execute("""
            INSERT INTO extracts
              (page_id, url, page_type, language, food_items, region_cuisine,
               occasion, emotions, key_snippets, raw_llm_output)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            page_id, url, page_type, language,
            food_items, region_cuisine, occasion, emotions,
            key_snippets, raw_llm_output
        ))
        conn.commit()
    except Exception as e:
        print(f"[DB] Error saving extract for {url}: {e}")
    finally:
        conn.close()


def save_recipe(page_id, url, source_site, language, recipe_data):
    """Save a structured recipe to SQLite."""
    conn = get_connection()
    cur = conn.cursor()
    try:
        ingredients = recipe_data.get("ingredients", [])
        method      = recipe_data.get("method", [])
        if isinstance(ingredients, list):
            ingredients = json.dumps(ingredients, ensure_ascii=False)
        if isinstance(method, list):
            method = json.dumps(method, ensure_ascii=False)

        cur.execute("""
            INSERT OR IGNORE INTO recipes
              (page_id, url, source_site, language, dish_name, description,
               cuisine, region, ingredients, method, servings, prep_time,
               cook_time, total_time, occasion, dietary, language_of_origin,
               extraction_source)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            page_id, url, source_site, language,
            recipe_data.get("dish_name", ""),
            recipe_data.get("description", ""),
            recipe_data.get("cuisine", ""),
            recipe_data.get("region", ""),
            ingredients, method,
            recipe_data.get("servings", ""),
            recipe_data.get("prep_time", ""),
            recipe_data.get("cook_time", ""),
            recipe_data.get("total_time", ""),
            recipe_data.get("occasion", ""),
            recipe_data.get("dietary", ""),
            recipe_data.get("language_of_origin", language),
            recipe_data.get("source", "unknown"),
        ))
        conn.commit()
        page_id_out = cur.lastrowid
    except Exception as e:
        print(f"[DB] Error saving recipe {url}: {e}")
        page_id_out = None
    finally:
        conn.close()
    return page_id_out


def get_unextracted_pages():
    """Return pages that haven't been through LLM extraction yet."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT p.* FROM pages p
        LEFT JOIN extracts e ON p.id = e.page_id
        WHERE e.id IS NULL
          AND p.page_type != 'recipe'
          AND p.page_type != 'other'
          AND p.raw_text IS NOT NULL
          AND length(p.raw_text) > 200
    """)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def export_to_csv(output_path="data/extracts_export.csv"):
    """Export all extracts to a CSV file."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT e.url, e.page_type, e.language, e.food_items, e.region_cuisine,
               e.occasion, e.emotions, e.key_snippets, p.title, p.source_site
        FROM extracts e
        LEFT JOIN pages p ON e.page_id = p.id
    """)
    rows = cur.fetchall()
    conn.close()

    if not rows:
        print("[Export] No extracts to export yet.")
        return

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["url", "page_type", "language", "food_items", "region_cuisine",
                         "occasion", "emotions", "key_snippets", "title", "source_site"])
        for row in rows:
            writer.writerow(list(row))

    print(f"[Export] Saved {len(rows)} rows to {output_path}")


def get_stats():
    """Print a quick summary of what's in the DB."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM pages")
    total_pages = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM extracts")
    total_extracts = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM recipes")
    total_recipes = cur.fetchone()[0]
    cur.execute("SELECT page_type, COUNT(*) as cnt FROM pages GROUP BY page_type")
    by_type = cur.fetchall()
    conn.close()

    print(f"\n{'='*40}")
    print(f"  Pages crawled   : {total_pages}")
    print(f"  Recipes mined   : {total_recipes}")
    print(f"  LLM extracts    : {total_extracts}")
    print(f"  Breakdown by type:")
    for row in by_type:
        print(f"    {row[0]:15s}: {row[1]}")
    print(f"{'='*40}\n")
