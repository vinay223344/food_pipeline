# classifier.py — Page Type Classifier

## What Does the Classifier Do?

The classifier reads the text of a page and assigns it a **type label** — what kind of food content is this?

**Input:** `{raw_text, title}` from extractor
**Output:** Same dict with `page_type` added

**Possible labels:**
- `recipe` — has ingredients and cooking instructions
- `story` — personal food memory or narrative
- `experience` — first-person food experience
- `review` — restaurant or product review
- `travel` — food encountered while travelling
- `song` — food-related song, poem, or lyrics
- `article` — general food article (catch-all)
- `other` — food-related but unclear

---

## Why Rule-Based (Not LLM)?

The classifier runs on **every single page** — potentially thousands. Using an LLM for every page would be:
- Slow (1-2 seconds per page)
- Expensive (API cost per call)
- Unnecessary (keyword matching is 95% accurate for this task)

Rule-based classification is **instant and free**. The LLM is only used in Stage 4 for deep extraction.

---

## How It Works: Keyword Scoring

Each page type has a list of **signal words**. We count how many signal words appear in the page text. The type with the highest count wins.

```python
def classify(raw_text, title=""):
    combined = (title + " " + raw_text).lower()
    
    scores = {
        "recipe":     count_signals(combined, RECIPE_SIGNALS),
        "story":      count_signals(combined, STORY_SIGNALS),
        "experience": count_signals(combined, EXPERIENCE_SIGNALS),
        "review":     count_signals(combined, REVIEW_SIGNALS),
        "travel":     count_signals(combined, TRAVEL_SIGNALS),
        "song":       count_signals(combined, SONG_SIGNALS),
    }
    
    best_type  = max(scores, key=scores.get)
    best_score = scores[best_type]
    
    if best_score == 0:
        return "article"  # food-related but no strong signal
    
    if scores["recipe"] == best_score:
        return "recipe"   # recipe wins ties
    
    return best_type
```

---

## Signal Word Lists

### Recipe Signals
```python
RECIPE_SIGNALS = [
    # English
    "ingredients", "instructions", "method", "preparation",
    "serves", "servings", "prep time", "cook time", "total time",
    "tablespoon", "teaspoon", "cup of",
    # Hindi
    "सामग्री", "विधि", "बनाने की विधि",
    # Bengali
    "উপকরণ", "প্রণালী",
    # Telugu
    "పదార్థాలు", "తయారీ విధానం",
    # Tamil
    "பொருட்கள்", "செய்முறை",
]
```

### Story Signals
```python
STORY_SIGNALS = [
    "memory", "memories", "childhood", "grandmother", "grandma",
    "nostalgia", "reminds me", "growing up", "my mother", "my father",
    "family recipe", "tradition", "festival", "celebration", "story", "tales",
    # Hindi
    "याद", "दादी", "नानी", "बचपन", "परंपरा",
    # Bengali
    "স্মৃতি", "দাদি", "ঐতিহ্য",
]
```

### Experience Signals
```python
EXPERIENCE_SIGNALS = [
    "i tried", "i ate", "i visited", "we had", "tasted", "first time",
    "experience", "journey", "travel", "trip", "street food", "market",
    # Hindi
    "मैंने खाया", "मैंने चखा",
]
```

### Review Signals
```python
REVIEW_SIGNALS = [
    "review", "rating", "stars", "recommend", "worth it", "must try",
    "overrated", "underrated", "ambiance", "service", "price", "value",
    "zomato", "swiggy", "yelp",
]
```

### Travel Signals
```python
TRAVEL_SIGNALS = [
    "travel", "trip", "visited", "tour", "destination", "city", "state",
    "region", "local food", "street food", "food trail", "food walk",
]
```

### Song Signals
```python
SONG_SIGNALS = [
    "song", "lyrics", "geet", "bhajan", "folk song",
    "गीत", "भजन", "लोकगीत",
    "গান", "লোকগীত",
]
```

---

## Scoring Examples

### Example 1: Recipe Page

**Text:** "Kanda Bhaji Recipe. Ingredients: 2 onions, 1 cup besan. Instructions: Mix ingredients. Prep time: 10 mins. Serves: 4."

```
recipe:     4 signals (ingredients, instructions, prep time, serves)
story:      0 signals
experience: 0 signals
review:     0 signals
travel:     0 signals
song:       0 signals

Winner: recipe (score=4)
```

### Example 2: Food Story

**Text:** "Every Diwali, my grandmother would make chakli. The memories of her kitchen still bring nostalgia. Growing up in Pune, this was a family tradition we celebrated every year."

```
recipe:     0 signals
story:      5 signals (grandmother, memories, nostalgia, growing up, tradition)
experience: 0 signals
review:     0 signals
travel:     0 signals
song:       0 signals

Winner: story (score=5)
```

### Example 3: Restaurant Review

**Text:** "I visited this restaurant last week. Rating: 4/5 stars. The service was excellent. I recommend the biryani. Worth it for the price."

```
recipe:     0 signals
story:      0 signals
experience: 1 signal (i visited)
review:     5 signals (rating, stars, recommend, worth it, price)
travel:     1 signal (visited)
song:       0 signals

Winner: review (score=5)
```

### Example 4: Travel Food Post

**Text:** "During my trip to Rajasthan, I tried street food at the local market. The dal baati churma was amazing. This destination has incredible local food."

```
recipe:     0 signals
story:      0 signals
experience: 3 signals (i tried, trip, street food)
review:     0 signals
travel:     5 signals (trip, visited, destination, local food, street food)
song:       0 signals

Winner: travel (score=5)
```

### Example 5: Zero Score → Article

**Text:** "Dal is a staple food in Indian cuisine. It is made from lentils and is eaten across the country."

```
recipe:     0 signals
story:      0 signals
experience: 0 signals
review:     0 signals
travel:     0 signals
song:       0 signals

All scores = 0 → return "article"
```

### Example 6: Tie-Break (Recipe Wins)

**Text:** "My grandmother's recipe for dal. Ingredients: 1 cup dal, 2 tomatoes. Method: Boil dal. This is a family tradition."

```
recipe: 3 signals (recipe, ingredients, method)
story:  2 signals (grandmother, tradition)

Tie-break: recipe wins → return "recipe"
```

---

## Hindi/Bengali Classification Example

**Text (Hindi):** "दादी की रेसिपी। सामग्री: 1 कप दाल, 2 टमाटर। विधि: दाल उबालें।"

```
recipe: 2 signals (सामग्री, विधि)
story:  1 signal (दादी)

Winner: recipe (score=2)
```

---

## Limitations

| Situation | Issue | Example |
|---|---|---|
| Mixed content | A recipe post with a long personal story intro | May classify as "story" instead of "recipe" |
| Very short pages | Not enough text to score | Returns "article" |
| Sarcastic reviews | "Totally NOT worth it" | Scores as review (correct) but sentiment wrong |
| New page types | Song pages are rare, may score as "article" | Acceptable |

The classifier is a **first-pass filter**. The LLM in Stage 4 does the deep understanding. The classifier just needs to be good enough to route pages to the right extraction path.
