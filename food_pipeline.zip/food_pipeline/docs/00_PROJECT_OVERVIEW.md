# Indian Food Data Mining Pipeline — Project Overview

## What Is This Project?

This project builds a **comprehensive database of Indian food knowledge** by automatically crawling food-related websites, extracting structured information, and storing it in MongoDB.

The end goal is to power a **knowledge graph of Indian cuisine** — covering recipes, food stories, cultural experiences, regional dishes, and food memories across all Indian languages and the broader Indian subcontinent.

---

## Why Does This Exist?

Indian food knowledge is scattered across:
- Thousands of recipe blogs (English and vernacular)
- Personal food stories and memories
- Travel food experiences
- Restaurant reviews
- YouTube channels
- Books and datasets
- Regional language blogs (Hindi, Telugu, Bengali, Tamil, Gujarati, etc.)

No single structured database captures all of this. This pipeline **automatically mines, classifies, and structures** that scattered knowledge.

---

## What Does the Pipeline Do?

Given a website URL, the pipeline:

1. **Crawls** the entire website — follows every internal link, goes deep
2. **Extracts** clean text from each page — removes ads, navigation, noise
3. **Detects** the language of each page
4. **Classifies** each page — is it a recipe? A food story? A review?
5. **Extracts structured data**:
   - For recipes → dish name, ingredients (with quantities), method steps, cook time
   - For stories/experiences → food items mentioned, region, emotions, occasions
6. **Stores** everything in MongoDB with proper structure
7. **Exports** to CSV/JSON for analysis

---

## Two Types of Content We Handle

### Type 1: Recipes (Structured)
```
Input (raw blog post):
"Kanda Bhaji is a popular Maharashtrian snack. You need 2 onions,
1 cup besan, salt, green chili. Mix and deep fry."

Output (structured):
{
  "dish_name": "Kanda Bhaji",
  "cuisine": "Maharashtrian",
  "ingredients": [
    {"item": "onions", "quantity": "2", "unit": "whole"},
    {"item": "besan", "quantity": "1", "unit": "cup"},
    {"item": "salt", "quantity": "to taste"},
    {"item": "green chili", "quantity": "1", "unit": "whole"}
  ],
  "method": ["Mix all ingredients", "Deep fry until golden"]
}
```

### Type 2: Non-Recipe Content (Unstructured)
```
Input (personal food story):
"Every Diwali, my grandmother would make chakli in the kitchen.
The smell of roasted rice flour still takes me back to childhood
in Pune. She never measured anything — just knew by feel."

Output (structured):
{
  "food_items": ["chakli", "rice flour"],
  "region_cuisine": "Maharashtrian",
  "occasion": "Diwali festival",
  "emotions": "nostalgia, comfort, family warmth",
  "key_snippets": [
    "Every Diwali, my grandmother would make chakli in the kitchen.",
    "She never measured anything — just knew by feel."
  ]
}
```

---

## Technology Stack

| Component | Technology | Why |
|---|---|---|
| Web Crawling | `requests` + `BeautifulSoup` | Simple, reliable, handles most blogs |
| Text Cleaning | `BeautifulSoup` + `lxml` | Fast HTML parsing |
| Language Detection | `langdetect` | Supports 55 languages including Indian languages |
| Recipe Extraction | `recipe-scrapers` | Supports 500+ known recipe sites |
| LLM Extraction | `Mistral AI` (mistral-small) | Fast, cheap, good multilingual support |
| Database | `MongoDB` (local) | Native JSON storage, arrays as arrays |
| Backup DB | `SQLite` | Lightweight, no setup needed |
| Web UI | `Streamlit` | Pure Python, no frontend needed |
| Config | `python-dotenv` | Keeps secrets out of code |

---

## Project File Structure

```
food_pipeline/
│
├── .env                    ← Secret keys (never commit this)
├── .gitignore              ← Ignores .env, cache, DB files
├── requirements.txt        ← All Python dependencies
│
├── config.py               ← All settings loaded from .env
├── crawler.py              ← Stage 1: Web crawling
├── extractor.py            ← Stage 2: Text extraction
├── classifier.py           ← Stage 3: Page classification
├── recipe_extractor.py     ← Stage 4a: Recipe data extraction
├── llm_extractor.py        ← Stage 4b: Non-recipe LLM extraction
├── storage_mongo.py        ← MongoDB storage layer
├── storage.py              ← SQLite storage layer (backup)
├── main.py                 ← CLI entry point
├── app.py                  ← Streamlit web UI
│
├── data/
│   ├── food_data.db        ← SQLite database file
│   └── extracts_export.csv ← CSV export
│
└── docs/                   ← This documentation
```

---

## How to Run

### Start the Web UI
```bash
cd D:\sample\food_pipeline
streamlit run app.py
# Open http://localhost:8501
```

### Run from Command Line
```bash
# Full pipeline on a URL
python main.py --url https://indiaphile.info/posts/ --depth 2 --mongo

# Crawl only (no LLM)
python main.py --url https://indiaphile.info/posts/ --depth 1 --mongo --no-llm

# Check database stats
python main.py --stats --mongo

# Export to CSV
python main.py --export --mongo
```

---

## MongoDB Collections

After running the pipeline, MongoDB (`indian_food_db`) has 3 collections:

| Collection | What it stores | Example count |
|---|---|---|
| `pages` | Every crawled page (raw) | 124 pages |
| `recipes` | Structured recipe data | 107 recipes |
| `extracts` | Non-recipe LLM output | 16 extracts |

---

## Read the Detailed Docs

| File | What it covers |
|---|---|
| `01_CONFIG.md` | Configuration and environment setup |
| `02_CRAWLER.md` | How the web crawler works |
| `03_EXTRACTOR.md` | Text extraction and language detection |
| `04_CLASSIFIER.md` | Page type classification |
| `05_RECIPE_EXTRACTOR.md` | Recipe data extraction |
| `06_LLM_EXTRACTOR.md` | Non-recipe LLM extraction |
| `07_STORAGE.md` | MongoDB and SQLite storage |
| `08_MAIN_PIPELINE.md` | How all stages connect |
| `09_UI.md` | Streamlit web interface |
| `10_EXAMPLES.md` | Real examples with input/output |
