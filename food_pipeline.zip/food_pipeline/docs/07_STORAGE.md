# storage_mongo.py & storage.py — Database Storage

## Overview

The pipeline has **two storage backends**:

| Backend | File | When to Use |
|---|---|---|
| MongoDB | `storage_mongo.py` | Default — use `--mongo` flag |
| SQLite | `storage.py` | Lightweight backup, no server needed |

Both have the **same function signatures** — you can swap between them with just the `--mongo` flag.

---

## MongoDB Storage (`storage_mongo.py`)

### Why MongoDB?

1. **Native JSON storage** — our data is already JSON dicts. MongoDB stores them as-is.
2. **Arrays as arrays** — `food_items: ["dal", "rice"]` stored as a real array, not a string. Enables direct queries.
3. **No schema required** — different pages can have different fields without migration.
4. **Scales well** — handles millions of documents easily.

### Connection

```python
from config import MONGO_URI, MONGO_DB

MONGO_URI = "mongodb://localhost:27017/"  # from .env
DB_NAME   = "indian_food_db"              # from .env

def get_db():
    global _client, _db
    if _db is None:
        _client = MongoClient(MONGO_URI)
        _db     = _client[DB_NAME]
    return _db
```

The connection is created **once** and reused (singleton pattern). This avoids creating a new connection for every database operation.

---

## Three Collections

### Collection 1: `pages`

Stores every crawled page — the raw data store.

```python
{
    "_id":         ObjectId("..."),
    "url":         "https://indiaphile.info/kanda-bhaji/",
    "title":       "Maharashtrian Kanda Bhaji",
    "raw_text":    "Kanda Bhaji is a popular Maharashtrian snack...",
    "language":    "en",
    "page_type":   "recipe",
    "source_site": "indiaphile.info",
    "crawled_at":  ISODate("2026-05-09T17:14:00Z")
}
```

**Unique index on `url`** — prevents the same page being stored twice even if crawled multiple times.

### Collection 2: `recipes`

Stores structured recipe data extracted from recipe pages.

```python
{
    "_id":              ObjectId("..."),
    "page_id":          ObjectId("..."),  # links to pages collection
    "url":              "https://indiaphile.info/kanda-bhaji/",
    "source_site":      "indiaphile.info",
    "language":         "en",
    "dish_name":        "Maharashtrian Kanda Bhaji",
    "description":      "Crispy onion fritters from Maharashtra",
    "cuisine":          "Indian",
    "region":           "",
    "ingredients": [                       # native array of objects
        {"item": "2 medium onions", "quantity": "2", "unit": "whole", "notes": "sliced"},
        {"item": "besan",           "quantity": "1", "unit": "cup",   "notes": "gram flour"},
        {"item": "salt",            "quantity": "1", "unit": "tsp",   "notes": "or to taste"}
    ],
    "method": [                            # native array of strings
        "Slice onions thinly and salt them. Let rest 10 minutes.",
        "Add besan, spices, and mix well.",
        "Heat oil and deep fry until golden brown."
    ],
    "servings":           "4 servings",
    "prep_time":          "10",
    "cook_time":          "20",
    "total_time":         "30",
    "occasion":           "",
    "dietary":            "vegetarian",
    "language_of_origin": "en",
    "extraction_source":  "recipe-scrapers",
    "extracted_at":       ISODate("2026-05-09T17:15:00Z")
}
```

### Collection 3: `extracts`

Stores LLM-extracted data from non-recipe pages.

```python
{
    "_id":            ObjectId("..."),
    "page_id":        ObjectId("..."),
    "url":            "https://ashtiw.wordpress.com/bundelkhand-food/",
    "page_type":      "story",
    "language":       "hi",
    "food_items":     ["Sannata", "buttermilk", "black salt", "bundi"],  # native array
    "region_cuisine": "Bundelkhandi cuisine",
    "occasion":       "marriage ceremony",
    "emotions":       "nostalgia, sentimental attachment, longing for home",
    "key_snippets":   [                                                   # native array
        "Sannata is a thin, runny, sour/tangy buttermilk...",
        "The poem reflects the fading memory of Bundelkhandi traditions..."
    ],
    "raw_llm_output": "{...full JSON...}",
    "extracted_at":   ISODate("2026-05-09T17:20:00Z")
}
```

---

## Indexes

Indexes make queries fast. Without them, MongoDB scans every document.

```python
def init_db():
    db = get_db()
    
    # pages indexes
    db.pages.create_index([("url", ASCENDING)], unique=True)  # dedup
    db.pages.create_index([("source_site", ASCENDING)])
    db.pages.create_index([("page_type", ASCENDING)])
    db.pages.create_index([("language", ASCENDING)])
    
    # recipes indexes
    db.recipes.create_index([("url", ASCENDING)], unique=True)
    db.recipes.create_index([("cuisine", ASCENDING)])
    db.recipes.create_index([("dish_name", ASCENDING)])
    db.recipes.create_index([("source_site", ASCENDING)])
    
    # extracts indexes
    db.extracts.create_index([("url", ASCENDING)])
    db.extracts.create_index([("page_type", ASCENDING)])
    db.extracts.create_index([("region_cuisine", ASCENDING)])
```

**Example query performance:**
```
Without index: db.recipes.find({"cuisine": "Gujarati"})
→ Scans all 107 documents → slow at scale

With index: same query
→ Jumps directly to Gujarati recipes → fast even with millions of docs
```

---

## Deduplication

### Pages
```python
def save_page(url, ...):
    try:
        db.pages.insert_one(doc)
        return result.inserted_id
    except DuplicateKeyError:
        # URL already exists — return existing _id
        existing = db.pages.find_one({"url": url}, {"_id": 1})
        return existing["_id"]
```

If you run the pipeline on the same URL twice, pages are not duplicated. The second run returns the existing `_id`.

### Recipes
```python
db.recipes.create_index([("url", ASCENDING)], unique=True)
# → insert_one raises DuplicateKeyError if URL already exists
```

---

## Useful MongoDB Queries

```javascript
// Count everything
db.pages.countDocuments()
db.recipes.countDocuments()
db.extracts.countDocuments()

// Find all Gujarati recipes
db.recipes.find({"cuisine": "Gujarati"})

// Find recipes with dal as ingredient
db.recipes.find({"ingredients.item": /dal/i})

// Find all food stories in Hindi
db.extracts.find({"page_type": "story", "language": "hi"})

// Find extracts mentioning biryani
db.extracts.find({"food_items": "biryani"})

// Top 10 most mentioned food items
db.extracts.aggregate([
    {$unwind: "$food_items"},
    {$group: {_id: "$food_items", count: {$sum: 1}}},
    {$sort: {count: -1}},
    {$limit: 10}
])

// All sites crawled with page counts
db.pages.aggregate([
    {$group: {_id: "$source_site", count: {$sum: 1}}},
    {$sort: {count: -1}}
])
```

---

## SQLite Storage (`storage.py`)

SQLite is a file-based database — no server needed. The database is a single file: `data/food_data.db`.

### Three Tables

```sql
CREATE TABLE pages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    url         TEXT    UNIQUE NOT NULL,
    title       TEXT,
    raw_text    TEXT,
    language    TEXT,
    page_type   TEXT,
    crawled_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    source_site TEXT
);

CREATE TABLE recipes (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    page_id             INTEGER REFERENCES pages(id),
    url                 TEXT UNIQUE,
    dish_name           TEXT,
    cuisine             TEXT,
    ingredients         TEXT,   -- JSON string: '[{"item":"..."}]'
    method              TEXT,   -- JSON string: '["step1", "step2"]'
    servings            TEXT,
    prep_time           TEXT,
    cook_time           TEXT,
    ...
);

CREATE TABLE extracts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    page_id         INTEGER REFERENCES pages(id),
    url             TEXT,
    page_type       TEXT,
    food_items      TEXT,   -- JSON string: '["dal", "rice"]'
    region_cuisine  TEXT,
    occasion        TEXT,
    emotions        TEXT,
    key_snippets    TEXT,   -- JSON string: '["snippet1", "snippet2"]'
    ...
);
```

**Key difference from MongoDB:** Arrays are stored as JSON strings in TEXT columns. To query them you need to parse the JSON first.

### When to Use SQLite

- Quick local testing without MongoDB running
- Sharing the database as a single file
- Simple analysis with SQL queries

```bash
# Use SQLite instead of MongoDB
python main.py --url https://example.com --depth 2
# (no --mongo flag = uses SQLite)
```

---

## CSV Export

Both storage backends support CSV export:

```python
store.export_to_csv("data/extracts_export.csv")
```

**Output columns:**
```
url | page_type | language | food_items | region_cuisine | occasion | emotions | key_snippets | title | source_site
```

**Example row:**
```csv
https://ashtiw.wordpress.com/bundelkhand-food/,story,hi,"[""Sannata"", ""buttermilk""]",Bundelkhandi cuisine,marriage ceremony,"nostalgia, longing","[""Sannata is a thin runny buttermilk...""]",Bundelkhand Food: Forgotten Recipes,ashtiw.wordpress.com
```
