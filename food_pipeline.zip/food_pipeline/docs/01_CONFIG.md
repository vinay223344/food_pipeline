# config.py — Configuration System

## What Is This File?

`config.py` is the **central settings file** for the entire pipeline. Every other file imports its settings from here. This means you only need to change one place to affect the whole system.

It uses `python-dotenv` to load sensitive values (like API keys) from a `.env` file instead of hardcoding them in the code.

---

## The `.env` File

The `.env` file stores secrets and environment-specific settings. It lives in the project root and is **never committed to version control** (it's in `.gitignore`).

```env
# .env file
MISTRAL_API_KEY=your_api_key_here
MISTRAL_MODEL=mistral-small-latest

MONGO_URI=mongodb://localhost:27017/
MONGO_DB_NAME=indian_food_db
```

**Why `.env`?**
- If you hardcode `MISTRAL_API_KEY = "abc123"` in `config.py` and push to GitHub, your key is exposed publicly
- With `.env`, the key stays on your machine only
- Different team members can have different keys without changing code

---

## How `config.py` Loads the `.env`

```python
from dotenv import load_dotenv
import os

load_dotenv()  # reads .env file from current directory

MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY", "")
MONGO_URI       = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
```

`os.getenv("KEY", "default")` — reads the value from environment, falls back to default if not found.

If `MISTRAL_API_KEY` is empty, the app raises a clear error:
```
EnvironmentError: MISTRAL_API_KEY not found.
Create a .env file with MISTRAL_API_KEY=your_key
```

---

## Crawler Settings

```python
CRAWL_DEPTH        = 3     # How deep to follow links
MAX_PAGES          = 100   # Stop after this many pages
RATE_LIMIT_SECONDS = 1.5   # Wait between requests
REQUEST_TIMEOUT    = 15    # Give up on a page after 15s
```

### What does `CRAWL_DEPTH` mean?

```
Depth 0:  https://indiaphile.info/posts/          ← seed URL
Depth 1:  https://indiaphile.info/kanda-bhaji/    ← linked from seed
Depth 2:  https://indiaphile.info/related-recipe/ ← linked from depth 1
Depth 3:  https://indiaphile.info/another-page/   ← linked from depth 2
```

Higher depth = more pages crawled = more time + more data.

### Why `RATE_LIMIT_SECONDS = 1.5`?

Without a delay, we'd send hundreds of requests per second to a website. This:
- Gets our IP blocked
- Overloads small blog servers
- Is considered rude/unethical

1.5 seconds between requests is polite and avoids blocks.

---

## Browser-Like Headers

```python
REQUEST_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) ...",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,...",
}
```

**Why?** Without these headers, our requests look like a bot and many sites return 403 (Forbidden). With browser-like headers, the site thinks a real Chrome browser is visiting.

**Example without headers:**
```
GET /recipes/ HTTP/1.1
Host: indiaphile.info
→ Response: 403 Forbidden
```

**Example with headers:**
```
GET /recipes/ HTTP/1.1
Host: indiaphile.info
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)...
→ Response: 200 OK
```

---

## URL Skip Patterns

```python
SKIP_URL_PATTERNS = [
    "privacy", "privacy-policy", "terms", "terms-of-use",
    "disclaimer", "cookie", "sitemap", "contact", "contact-us",
    "advertise", "about-us", "careers", "jobs",
    "login", "register", "signup", "account",
    "wp-login", "wp-admin", "feed", "rss",
    "newsletter", "subscribe",
]
```

**Why?** These pages contain no food content. Crawling them wastes time and pollutes the database.

**Example:**
```
https://indiaphile.info/privacy-policy/  → SKIP (matches "privacy-policy")
https://indiaphile.info/contact-us/      → SKIP (matches "contact-us")
https://indiaphile.info/kanda-bhaji/     → CRAWL (no match)
https://indiaphile.info/about/           → SKIP (matches "about-us"? No — "about" alone doesn't match)
```

Note: The match checks the URL path, so `about-us` matches but `about` alone does not (to avoid skipping legitimate pages with "about" in the title).

---

## LLM Text Truncation

```python
LLM_MAX_CHARS        = 2000   # for non-recipe pages
RECIPE_LLM_MAX_CHARS = 3000   # for recipe pages
```

**Why truncate?** Mistral has a token limit. Very long pages (some blogs have 50,000+ characters) would exceed the limit and cause errors.

**Strategy:** Take first 1000 chars + last 1000 chars. This captures the introduction (context) and conclusion (summary) of the article.

```
Original text: 10,000 characters
                ↓
Truncated:  [first 1000 chars] + "\n\n[...]\n\n" + [last 1000 chars]
            = 2000 characters sent to LLM
```

Recipe pages get 3000 chars because ingredients lists can be long.

---

## Food Keywords (Multilingual)

```python
FOOD_KEYWORDS = [
    # English
    "recipe", "food", "cook", "dish", "eat", "meal", "ingredient",
    "spice", "flavor", "taste", "kitchen", "restaurant", "curry", "rice",
    # Hindi
    "खाना", "रेसिपी", "मसाला", "रोटी", "चावल", "दाल",
    # Bengali
    "রান্না", "খাবার", "রেসিপি", "মশলা",
    # Telugu
    "వంట", "ఆహారం", "రెసిపీ",
    # Tamil
    "சமையல்", "உணவு",
    # Marathi
    "जेवण", "रेसिपी",
    # Gujarati
    "રસોઈ", "ખોરાક",
]
```

**How it's used:** Before spending time on LLM extraction, we do a quick check — does this page contain ANY food-related word? If not, skip it entirely.

**Example:**
```
Page text: "Top 10 JavaScript frameworks for 2024..."
→ No food keywords found → SKIP (not food related)

Page text: "My grandmother's dal recipe from Rajasthan..."
→ "dal", "recipe" found → PROCESS
```

---

## Page Types

```python
PAGE_TYPES = [
    "recipe",      # Has ingredients and cooking instructions
    "story",       # Personal food memory or narrative
    "experience",  # First-person food experience
    "review",      # Restaurant or product review
    "travel",      # Food encountered while travelling
    "song",        # Food-related song or poem
    "article",     # General food article (catch-all)
    "other",       # Food-related but unclear type
]
```

These are the labels the classifier assigns to each page.
