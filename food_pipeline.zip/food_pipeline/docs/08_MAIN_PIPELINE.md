# main.py — Pipeline Orchestrator

## What Does `main.py` Do?

`main.py` is the **conductor** — it calls all the other modules in the right order and passes data between them. It can be run from the command line or called by the Streamlit UI.

---

## Command Line Usage

```bash
# Full pipeline — crawl + extract + classify + LLM + save
python main.py --url https://indiaphile.info/posts/ --depth 2 --mongo

# Crawl only — no LLM extraction (fast, cheap)
python main.py --url https://indiaphile.info/posts/ --depth 1 --mongo --no-llm

# Check what's in the database
python main.py --stats --mongo

# Export everything to CSV
python main.py --export --mongo

# Use SQLite instead of MongoDB (no --mongo flag)
python main.py --url https://indiaphile.info/posts/ --depth 1
```

---

## The 5 Stages in Order

```python
def run_pipeline(seed_url, depth, run_llm=True, use_mongo=False):
    
    store = load_storage(use_mongo)  # MongoDB or SQLite
    store.init_db()                  # create collections/tables
    
    # Stage 1: Crawl
    pages = crawl(seed_url, depth=depth)
    
    # Stage 2+3: Extract + Classify + Save
    processed = []
    for page in pages:
        p = process_page(page)           # extract text, detect language
        if not p["is_food"]: continue    # skip non-food pages
        p = classify_page(p)             # label: recipe/story/etc
        db_id = store.save_page(...)     # save to DB
        p["id"] = db_id                  # attach DB id for later
        processed.append(p)
    
    # Stage 4a: Recipe Extraction
    recipe_pages = [p for p in processed if p["page_type"] == "recipe"]
    recipe_results = run_recipe_extraction_batch(recipe_pages)
    for page, recipe in recipe_results:
        store.save_recipe(...)
    
    # Stage 4b: Non-Recipe LLM Extraction
    non_recipe = [p for p in processed if p["page_type"] not in ("recipe", "other")]
    results = run_extraction_batch(non_recipe)
    for r in results:
        store.save_extract(...)
    
    # Stage 5: Summary
    store.get_stats()
    store.export_to_csv()
```

---

## Data Flow Between Stages

```
Stage 1 Output:
[
    {"url": "https://indiaphile.info/kanda-bhaji/", "html": "...", "title": "..."},
    {"url": "https://indiaphile.info/bhuna-gosht/", "html": "...", "title": "..."},
    {"url": "https://indiaphile.info/about/",       "html": "...", "title": "..."},
    ...
]

                    ↓ process_page() + classify_page()

Stage 2+3 Output (processed list):
[
    {"url": "...", "raw_text": "...", "language": "en", "page_type": "recipe", "id": ObjectId("...")},
    {"url": "...", "raw_text": "...", "language": "en", "page_type": "recipe", "id": ObjectId("...")},
    {"url": "...", "raw_text": "...", "language": "en", "page_type": "story",  "id": ObjectId("...")},
    ...
]

                    ↓ split by page_type

Stage 4a Input (recipe_pages):          Stage 4b Input (non_recipe):
[recipe, recipe, recipe, ...]           [story, experience, article, ...]

                    ↓                                   ↓
            run_recipe_extraction_batch()    run_extraction_batch()

                    ↓                                   ↓
            save_recipe() × N               save_extract() × N
```

---

## Storage Module Switching

```python
def load_storage(use_mongo=False):
    if use_mongo:
        import storage_mongo as store
    else:
        import storage as store
    return store
```

Both `storage_mongo` and `storage` have identical function names:
- `init_db()`
- `save_page(url, title, raw_text, language, page_type, source_site)`
- `save_recipe(page_id, url, source_site, language, recipe_data)`
- `save_extract(page_id, url, page_type, language, food_items, ...)`
- `get_stats()`
- `export_to_csv()`

This is the **strategy pattern** — swap the implementation without changing the calling code.

---

## HTML Map for Recipe Extraction

There's a subtle detail in Stage 4a:

```python
# The crawler returns pages with html
pages = crawl(seed_url)
# → [{"url": "...", "html": "...", "title": "..."}]

# But process_page() doesn't keep html in the output
# (raw_text is extracted, html is discarded to save memory)
processed = [process_page(p) for p in pages]
# → [{"url": "...", "raw_text": "...", ...}]  ← no html!

# recipe-scrapers needs the original HTML
# So we build a lookup map from the original pages list
html_map = {pg["url"].rstrip("/"): pg["html"] for pg in pages}

# Then attach html back to recipe pages before extraction
for p in recipe_pages:
    p["html"] = html_map.get(p["url"].rstrip("/"), "")
```

This is why we keep the original `pages` list around — to retrieve HTML for recipe extraction.

---

## Real Pipeline Run Output

```
============================================================
  INDIAN FOOD DATA MINING PIPELINE
  Storage: MongoDB
============================================================

[Stage 1] CRAWLING...
[Crawler] Starting crawl: https://indiaphile.info/posts/
[Crawler] Max depth=1, Max pages=100

  [001] depth=0 | https://indiaphile.info/posts/
  [002] depth=1 | https://indiaphile.info/kanda-bhaji
  [003] depth=1 | https://indiaphile.info/bhuna-gosht
  ...
  [024] depth=1 | https://indiaphile.info/payasam

[Crawler] Done. Collected 24 pages.

[Stage 2+3] EXTRACTING TEXT & CLASSIFYING 24 pages...
  [SAVED] [recipe      ] [en   ] https://indiaphile.info/kanda-bhaji/
  [SAVED] [recipe      ] [en   ] https://indiaphile.info/bhuna-gosht/
  [SAVED] [story       ] [en   ] https://indiaphile.info/region/gujarat/
  [SAVED] [story       ] [en   ] https://indiaphile.info/about/
  ...

  → 24 food-related pages saved to DB.

[Stage 4a] RECIPE EXTRACTION...
[Recipe Extractor] Processing 19 recipe pages...
  [001/19] https://indiaphile.info/kanda-bhaji/
           ✓ [library] Maharashtrian Kanda Bhaji | 10 ingredients | 6 steps
  [002/19] https://indiaphile.info/bhuna-gosht/
           ✓ [library] Bhuna Gosht | 20 ingredients | 6 steps
  ...
[Recipe Extractor] Done. 19/19 recipes extracted.

  → 19 recipes saved to DB.

[Stage 4b] NON-RECIPE LLM EXTRACTION...
[LLM] Starting extraction on 5 pages...
  [1/5] https://indiaphile.info/posts/
        ✓ Extracted: 34 food items | region: Pan-Indian
  [2/5] https://indiaphile.info/about/
        ✓ Extracted: 3 food items | region: Maharashtrian
  ...
[LLM] Done. 4/5 pages extracted successfully.

  → 4 extracts saved to DB.

[Stage 5] SUMMARY
========================================
  Database        : indian_food_db (MongoDB)
  Pages crawled   : 24
  LLM extracts    : 4
  Recipes mined   : 19
  Breakdown by type:
    recipe         : 19
    story          : 3
    article        : 1
    experience     : 1
========================================

[DONE] Pipeline complete.
  Database : MongoDB: indian_food_db
  CSV      : data/extracts_export_mongo.csv
```

---

## Error Handling

```python
pages = crawl(seed_url, depth=depth)

if not pages:
    print("[ERROR] No pages crawled. Check the URL and try again.")
    sys.exit(1)
```

If the crawler returns nothing (site blocked, wrong URL, network error), the pipeline stops immediately with a clear error message.

Individual page failures (timeout, parse error) are caught inside each module and logged — the pipeline continues with the remaining pages.
