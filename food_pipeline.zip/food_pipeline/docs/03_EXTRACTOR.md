# extractor.py — Text Extractor

## What Does the Extractor Do?

The extractor takes raw HTML from the crawler and converts it into:
1. **Clean plain text** — removes all HTML noise
2. **Metadata** — title, author, publish date
3. **Language** — detects what language the page is in
4. **Food relevance** — is this page actually about food?

**Input:** `{url, html, title}` from crawler
**Output:** `{url, title, author, date, raw_text, language, is_food}`

---

## The Problem: Raw HTML is Messy

A typical blog page HTML looks like this:

```html
<html>
  <head>...</head>
  <body>
    <nav>Home | Recipes | About | Contact</nav>        ← NOISE
    <header>My Food Blog</header>                       ← NOISE
    <aside>
      <div class="ads">Buy this product!</div>          ← NOISE
      <div class="popular">Popular Posts...</div>       ← NOISE
    </aside>
    
    <article>
      <h1>Kanda Bhaji Recipe</h1>                       ← CONTENT ✓
      <p>Kanda Bhaji is a crispy onion fritter...</p>   ← CONTENT ✓
      <ul>
        <li>2 onions, sliced</li>                       ← CONTENT ✓
        <li>1 cup besan</li>                            ← CONTENT ✓
      </ul>
    </article>
    
    <footer>Copyright 2024 | Privacy Policy</footer>    ← NOISE
    <script>analytics code...</script>                  ← NOISE
  </body>
</html>
```

We want ONLY the `<article>` content. Everything else is noise.

---

## Step 1: Strip Noise Tags

```python
NOISE_TAGS = ["nav", "header", "footer", "aside", "script",
              "style", "noscript", "form", "button", "iframe", "figure"]

def clean_html(html):
    soup = BeautifulSoup(html, "lxml")
    
    for tag in soup(NOISE_TAGS):
        tag.decompose()  # completely remove from tree
    
    return soup
```

After this step, the HTML tree no longer contains nav, footer, scripts, etc.

---

## Step 2: Find the Main Content Block

Not all blogs use `<article>` tags. We try multiple strategies:

```python
main = (
    soup.find("article")                                    # try <article>
    or soup.find("main")                                    # try <main>
    or soup.find(class_=re.compile(r"post|entry|content"))  # try CSS class
    or soup.find("body")                                    # fallback to body
    or soup                                                 # last resort
)
```

**Examples of what different blogs use:**

```
WordPress blogs:    <div class="entry-content">
Blogger blogs:      <div class="post-body">
Custom blogs:       <article class="blog-post">
Simple HTML blogs:  <div id="content">
```

Our regex `post|entry|content|article|blog` catches most of these.

---

## Step 3: Extract Plain Text

```python
def extract_text(html):
    main = clean_html(html)
    text = main.get_text(separator="\n", strip=True)
    text = re.sub(r"\n{3,}", "\n\n", text)  # collapse blank lines
    return text.strip()
```

**Before (HTML):**
```html
<h1>Kanda Bhaji Recipe</h1>
<p>Kanda Bhaji is a <strong>crispy</strong> onion fritter from Maharashtra.</p>
<ul><li>2 onions</li><li>1 cup besan</li></ul>
```

**After (plain text):**
```
Kanda Bhaji Recipe

Kanda Bhaji is a crispy onion fritter from Maharashtra.

2 onions
1 cup besan
```

---

## Step 4: Extract Metadata

### Title (3 fallback levels)
```python
# Priority 1: Open Graph meta tag (most reliable)
og_title = soup.find("meta", property="og:title")
# → <meta property="og:title" content="Kanda Bhaji Recipe | Indiaphile">

# Priority 2: HTML title tag
title_tag = soup.find("title")
# → <title>Kanda Bhaji Recipe | Indiaphile</title>

# Priority 3: First H1 heading
h1 = soup.find("h1")
# → <h1>Kanda Bhaji Recipe</h1>
```

### Author
```python
# Try meta tag first
author_meta = soup.find("meta", attrs={"name": "author"})
# → <meta name="author" content="Anita Jain">

# Fallback: CSS class
author_tag = soup.find(class_=re.compile(r"author|byline"))
# → <span class="author-name">Anita Jain</span>
```

### Publish Date
```python
# Try Open Graph date
date_meta = soup.find("meta", property="article:published_time")
# → <meta property="article:published_time" content="2023-11-15T10:30:00">

# Fallback: <time> tag
time_tag = soup.find("time")
# → <time datetime="2023-11-15">November 15, 2023</time>
```

---

## Step 5: Language Detection

```python
from langdetect import detect

def detect_language(text):
    sample = text[:1000]  # first 1000 chars is enough
    return detect(sample)  # returns ISO 639-1 code
```

**Examples:**
```
"Kanda Bhaji is a crispy onion fritter..."  → "en" (English)
"खाना बनाने की विधि बहुत सरल है..."         → "hi" (Hindi)
"রান্নার পদ্ধতি খুব সহজ..."                 → "bn" (Bengali)
"వంట చేయడం చాలా సులభం..."                  → "te" (Telugu)
"சமையல் முறை மிகவும் எளிது..."              → "ta" (Tamil)
```

The Bundelkhand blog (mixed Hindi/English) correctly returns `"hi"`.

---

## Step 6: Food Relevance Check

```python
def is_food_related(text):
    text_lower = text.lower()
    return any(keyword.lower() in text_lower for keyword in FOOD_KEYWORDS)
```

**Examples:**
```
"Top 10 JavaScript frameworks for 2024..."
→ No food keywords → is_food = False → SKIP

"My grandmother's dal recipe from Rajasthan..."
→ "dal", "recipe" found → is_food = True → PROCESS

"खाना बनाने की विधि..."
→ "खाना" found → is_food = True → PROCESS
```

---

## Complete Output Example

**Input:** HTML from `https://indiaphile.info/kanda-bhaji/`

**Output:**
```python
{
    "url":      "https://indiaphile.info/kanda-bhaji/",
    "title":    "Maharashtrian Kanda Bhaji",
    "author":   "Anita Jain",
    "date":     "2023-08-15T10:00:00",
    "raw_text": "Maharashtrian Kanda Bhaji\n\nKanda Bhaji is a popular "
                "Maharashtrian snack made with sliced onions coated in "
                "spiced besan batter and deep fried...\n\nIngredients\n"
                "2 medium onions\n1 cup besan\n1 tsp salt...",
    "language": "en",
    "is_food":  True
}
```

---

## What Happens to Non-Food Pages?

```python
for page in crawled_pages:
    p = process_page(page)
    
    if not p["is_food"]:
        print(f"[SKIP] Not food-related: {p['url']}")
        continue  # don't process further, don't save to DB
    
    # continue to classifier...
```

Non-food pages are silently dropped. They never reach the classifier or LLM.

---

## Handling Different Blog Platforms

| Platform | Main content tag | Works? |
|---|---|---|
| WordPress | `<div class="entry-content">` | ✅ |
| Blogger | `<div class="post-body">` | ✅ |
| Ghost | `<section class="post-content">` | ✅ |
| Medium | `<article>` | ✅ |
| Custom HTML | `<article>` or `<main>` | ✅ |
| React/Next.js (JS-rendered) | Empty without JS | ⚠️ Partial |
