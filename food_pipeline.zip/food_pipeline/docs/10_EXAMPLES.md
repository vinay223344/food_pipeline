# Real Examples — Input to Output

This document shows complete real examples of what the pipeline does at each stage, using actual data from our test runs.

---

## Example 1: Recipe Page (Library Extraction)

### Source
URL: `https://indiaphile.info/surti-undhiyu/`
Site: indiaphile.info (WordPress blog)

### Stage 1 Output (Crawler)
```python
{
    "url":   "https://indiaphile.info/surti-undhiyu/",
    "html":  "<!DOCTYPE html>...(full HTML, ~45KB)...",
    "title": "Surti Undhiyu (Instant Pot Method) | Indiaphile"
}
```

### Stage 2 Output (Extractor)
```python
{
    "url":      "https://indiaphile.info/surti-undhiyu/",
    "title":    "Surti Undhiyu (Instant Pot Method)",
    "author":   "Anita Jain",
    "date":     "2022-01-15T10:00:00",
    "raw_text": "Surti Undhiyu (Instant Pot Method)\n\nUndhiyu is a "
                "traditional Gujarati mixed vegetable dish...\n\n"
                "Ingredients\n1 cup fresh green garlic\n2 cups surti papdi...",
    "language": "en",
    "is_food":  True
}
```

### Stage 3 Output (Classifier)
```python
# Scores:
# recipe: 5 (ingredients, method, prep time, cook time, serves)
# story:  1 (tradition)
# → page_type = "recipe"

{
    ...same as above...,
    "page_type": "recipe"
}
```

### Stage 4a Output (Recipe Extractor — Library)
```python
{
    "dish_name":   "Surti Undhiyu (Instant Pot Method)",
    "description": "Traditional Gujarati mixed vegetable dish cooked in Instant Pot",
    "cuisine":     "Indian",
    "region":      "",
    "ingredients": [
        {"item": "1 cup fresh green garlic (lila lasan)", "quantity": "", "unit": "", "notes": ""},
        {"item": "2 cups surti papdi (flat green beans)", "quantity": "", "unit": "", "notes": ""},
        {"item": "1 cup fresh tuvar (pigeon peas)",        "quantity": "", "unit": "", "notes": ""},
        {"item": "2 medium potatoes, cubed",               "quantity": "", "unit": "", "notes": ""},
        {"item": "1 cup raw banana, cubed",                "quantity": "", "unit": "", "notes": ""},
        {"item": "1/2 cup fresh coconut, grated",          "quantity": "", "unit": "", "notes": ""},
        {"item": "1/4 cup cilantro",                       "quantity": "", "unit": "", "notes": ""},
        {"item": "2 tbsp sesame seeds",                    "quantity": "", "unit": "", "notes": ""},
        {"item": "1 tsp ajwain (carom seeds)",             "quantity": "", "unit": "", "notes": ""},
        {"item": "1 tsp cumin seeds",                      "quantity": "", "unit": "", "notes": ""},
        {"item": "1/2 tsp turmeric",                       "quantity": "", "unit": "", "notes": ""},
        {"item": "1 tsp red chili powder",                 "quantity": "", "unit": "", "notes": ""},
        {"item": "2 tsp coriander-cumin powder",           "quantity": "", "unit": "", "notes": ""},
        {"item": "1 tbsp sugar",                           "quantity": "", "unit": "", "notes": ""},
        {"item": "Salt to taste",                          "quantity": "", "unit": "", "notes": ""},
        {"item": "3 tbsp oil",                             "quantity": "", "unit": "", "notes": ""},
        ...
    ],
    "method": [
        "Make the masala: Blend coconut, cilantro, sesame seeds, ajwain...",
        "Prep the vegetables: Wash and cut all vegetables...",
        "Layer in Instant Pot: Add oil, then layer vegetables...",
        "Pressure cook: Set Instant Pot to high pressure for 3 minutes...",
        "Release pressure and mix gently...",
        ...
    ],
    "servings":   "6 servings",
    "prep_time":  "30",
    "cook_time":  "15",
    "total_time": "45",
    "occasion":   "",
    "dietary":    "vegetarian",
    "extraction_source": "recipe-scrapers"
}
```

### MongoDB Document (recipes collection)
```json
{
  "_id": "69ff6b94f27a77a1254ce340",
  "page_id": "69ff6b70f27a77a1254ce320",
  "url": "https://indiaphile.info/surti-undhiyu/",
  "source_site": "indiaphile.info",
  "language": "en",
  "dish_name": "Surti Undhiyu (Instant Pot Method)",
  "cuisine": "Indian",
  "ingredients": [...26 items...],
  "method": [...22 steps...],
  "servings": "6 servings",
  "prep_time": "30",
  "cook_time": "15",
  "extraction_source": "recipe-scrapers",
  "extracted_at": "2026-05-09T17:15:00Z"
}
```

---

## Example 2: Food Story (LLM Extraction)

### Source
URL: `https://indiaphile.info/about/`
Site: indiaphile.info

### Stage 3 Output (Classifier)
```python
# Scores:
# recipe:  0
# story:   3 (growing up, family, tradition)
# → page_type = "story"
```

### Raw Text (truncated)
```
I'm Anita, a Maharashtrian who grew up in Bombay with a Gujarati
influence. I enjoyed cooking even as a very young child and could
make rotlis on my own by the time I was 8. My favorite was bhinda
(okra). Every recipe on this site comes from my family kitchen in
Pune and Bombay.
```

### Stage 4b Output (LLM Extractor)
```python
{
    "page_id":        ObjectId("..."),
    "url":            "https://indiaphile.info/about/",
    "page_type":      "story",
    "language":       "en",
    "food_items":     ["rotlis", "bhinda", "okra"],
    "region_cuisine": "Maharashtrian (Bombay and Maharashtra) with influences from Gujarat",
    "occasion":       "",
    "emotions":       "pride, nostalgia, family warmth, rejection of traditional gender roles",
    "key_snippets":   [
        "I enjoyed cooking even as a very young child and could make rotlis on my own by the time I was 8.",
        "My favorite was bhinda.",
        "Every recipe on this site comes from my family kitchen in Pune and Bombay."
    ],
    "raw_llm_output": "{...full JSON...}"
}
```

---

## Example 3: Unstructured Blog (LLM Recipe Fallback)

### Source
URL: `https://gitaskitchen.blogspot.com/meen-kuzhumbu.html`
Site: Blogger blog (no JSON-LD schema)

### Why Library Fails
```
recipe-scrapers: scrape_html(html, wild_mode=True)
→ NoSchemaFoundInWildMode exception
→ Fall back to LLM
```

### Raw Text Sent to LLM
```
Meen Kuzhumbu / Spicy Fish Gravy

This is a traditional Tamil fish curry that my mother used to make
every Friday. The tamarind gives it a beautiful tangy flavor.

Ingredients:
- 500g fish (I use seer fish / king fish)
- 2 tbsp sesame oil (nallennai)
- 1 tsp mustard seeds
- 10-12 curry leaves
- 2 medium tomatoes, chopped
- 2 tbsp tamarind paste
- 1 tsp red chili powder
- 1/2 tsp turmeric powder
- Salt to taste

Method:
Heat sesame oil in a clay pot. Add mustard seeds and let them splutter.
Add curry leaves. Add tomatoes and cook till mushy. Add tamarind paste,
chili powder, turmeric. Add fish pieces. Cook covered for 15 minutes.
Serve with rice.
```

### LLM Output
```json
{
  "dish_name": "Meen Kuzhumbu / Spicy Fish Gravy",
  "description": "Traditional Tamil fish curry with tamarind and sesame oil",
  "cuisine": "Tamil",
  "region": "Tamil Nadu",
  "ingredients": [
    {"item": "fish (seer fish / king fish)", "quantity": "500", "unit": "g", "notes": ""},
    {"item": "sesame oil (nallennai)",        "quantity": "2",   "unit": "tbsp", "notes": ""},
    {"item": "mustard seeds",                 "quantity": "1",   "unit": "tsp", "notes": ""},
    {"item": "curry leaves",                  "quantity": "10",  "unit": "whole", "notes": ""},
    {"item": "tomatoes",                      "quantity": "2",   "unit": "medium", "notes": "chopped"},
    {"item": "tamarind paste",                "quantity": "2",   "unit": "tbsp", "notes": ""},
    {"item": "red chili powder",              "quantity": "1",   "unit": "tsp", "notes": ""},
    {"item": "turmeric powder",               "quantity": "0.5", "unit": "tsp", "notes": ""},
    {"item": "salt",                          "quantity": "",    "unit": "to taste", "notes": ""}
  ],
  "method": [
    "Heat sesame oil in a clay pot",
    "Add mustard seeds and let them splutter",
    "Add curry leaves",
    "Add tomatoes and cook until mushy",
    "Add tamarind paste, chili powder, and turmeric",
    "Add fish pieces and cook covered for 15 minutes",
    "Serve hot with rice"
  ],
  "servings": "4",
  "prep_time": "10",
  "cook_time": "20",
  "total_time": "30",
  "occasion": "everyday meal, Friday tradition",
  "dietary": "non-vegetarian",
  "language_of_origin": "en"
}
```

---

## Example 4: Mixed Hindi-English Blog (Bundelkhand)

### Source
URL: `https://ashtiw.wordpress.com/bundelkhand-food-forgotten-recipes/`

### Extractor Output
```python
{
    "language": "hi",    # detected as Hindi (mixed content)
    "is_food":  True,    # "खाना", "recipe" found
    "raw_text": "Bundelkhand (बुन्देलखण्ड)… region located nearly at "
                "center of heartland of India…\n\nकहाँ गये वे कुँवर कलेऊ\n"
                "दोना पातर कहाँ गये\n\nSannata is a thin, runny, sour/tangy "
                "buttermilk with spices including black salt and bundi..."
}
```

### Classifier Output
```python
# story signals: "memories", "tradition", "याद" found
# page_type = "story"
```

### LLM Extraction Output
```python
{
    "food_items":     ["Sannata", "buttermilk", "black salt", "bundi",
                       "kulevu", "daal", "baati", "churma"],
    "region_cuisine": "Bundelkhandi cuisine",
    "occasion":       "marriage ceremony, everyday meals",
    "emotions":       "nostalgia, sentimental attachment, longing for home, forgetfulness",
    "key_snippets":   [
        "Sannata is a thin, runny, sour/tangy buttermilk with spices including black salt and bundi, traditionally made thin due to poverty in the region.",
        "The poem reflects the fading memory of Bundelkhandi marriage ceremonies and associated food traditions."
    ],
    "language_of_origin": "hi"
}
```

---

## Example 5: Non-Food Page (Skipped)

### Source
URL: `https://indiaphile.info/privacy-policy/`

### What Happens
```
Stage 1: Crawler
→ URL path contains "privacy-policy"
→ should_skip() returns True
→ URL never added to crawl queue
→ Page never fetched
```

The privacy policy page is filtered out **before** any HTTP request is made.

---

## Example 6: Database Stats After Two Sites

After crawling `indiaphile.info` and `gitaskitchen.blogspot.com`:

```
========================================
  Database        : indian_food_db (MongoDB)
  Pages crawled   : 124
  LLM extracts    : 16
  Recipes mined   : 107
  Breakdown by type:
    recipe         : 107
    story          :   5
    article        :   9
    experience     :   1
    review         :   1
    travel         :   1
========================================
```

### MongoDB Query Examples on This Data

```javascript
// How many Gujarati recipes?
db.recipes.countDocuments({"cuisine": /Gujarati/i})
// → 8

// All recipes from gitaskitchen
db.recipes.find({"source_site": "gitaskitchen.blogspot.com"}).count()
// → 88

// Find all recipes with coconut
db.recipes.find({"ingredients.item": /coconut/i})

// Find food stories with nostalgia
db.extracts.find({"emotions": /nostalgia/i, "page_type": "story"})

// Top 5 most mentioned food items
db.extracts.aggregate([
    {$unwind: "$food_items"},
    {$group: {_id: "$food_items", count: {$sum: 1}}},
    {$sort: {count: -1}},
    {$limit: 5}
])
// → dal, rice, coconut, curry leaves, mustard seeds
```
