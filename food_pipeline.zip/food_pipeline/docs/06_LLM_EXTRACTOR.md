# llm_extractor.py — Non-Recipe LLM Extraction

## What Does the LLM Extractor Do?

For pages that are NOT recipes — stories, experiences, reviews, travel posts, articles — this module uses **Mistral AI** to read the text and extract structured food intelligence.

The key insight: even unstructured text like a personal food memory contains valuable information — what foods are mentioned, what region they're from, what emotions are associated with them. The LLM can understand this context.

**Input:** Non-recipe page dict `{url, raw_text, page_type, language}`
**Output:** Structured extract dict with food items, region, emotions, snippets

---

## Why LLM for This?

Rule-based extraction can find keywords, but it can't understand context:

```
Text: "The smell of my mother's biryani on Eid morning is something
       I will never forget. We would wake up early and the whole
       house smelled of saffron and cardamom."

Rule-based can find: "biryani", "saffron", "cardamom"
LLM can understand:
  - food_items: ["biryani", "saffron", "cardamom"]
  - occasion: "Eid festival"
  - emotions: "nostalgia, warmth, family love"
  - region: "Muslim household, likely North Indian or Hyderabadi"
  - key_snippet: "The smell of my mother's biryani on Eid morning is
                  something I will never forget."
```

---

## The System Prompt

```python
SYSTEM_PROMPT = """
You are an expert in Indian food culture, cuisine, and culinary history.
Your task is to analyze a piece of text about Indian food and extract
structured information from it.
Always respond with valid JSON only — no markdown, no explanation,
just the JSON object.
"""
```

**Why this system prompt?**
- Establishes the LLM as a domain expert (improves accuracy)
- Instructs it to return JSON only (prevents prose responses)
- "No markdown" prevents ```json code fences that break parsing

---

## The Extraction Prompt

```python
EXTRACTION_PROMPT = """
Analyze the following text about Indian food and extract the information below.

Text:
\"\"\"
{text}
\"\"\"

Return a JSON object with exactly these fields:
{
  "food_items": ["list of specific food items, dishes, or ingredients mentioned"],
  "region_cuisine": "the Indian region or cuisine style",
  "occasion": "occasion or context if mentioned",
  "emotions": "emotions or sentiments expressed about the food",
  "key_snippets": ["2-3 most interesting sentences from the text about food"],
  "language_of_origin": "the language this content was originally written in",
  "content_summary": "one sentence summary of what this text is about"
}

Rules:
- food_items and key_snippets must be JSON arrays
- If a field has no relevant information, use "" or []
- Do not add any fields beyond the ones listed above
- Respond with JSON only
"""
```

**Why `temperature=0.1`?**
Low temperature makes the LLM more deterministic and consistent. We want structured JSON output, not creative writing.

---

## Text Truncation

Long pages are truncated before sending to the LLM:

```python
def truncate_text(text, max_chars=2000):
    if len(text) <= max_chars:
        return text
    
    half = max_chars // 2  # = 1000
    return text[:1000] + "\n\n[...]\n\n" + text[-1000:]
```

**Why first + last?**
- First 1000 chars: usually the introduction — sets context, mentions the topic
- Last 1000 chars: usually the conclusion — summarizes key points
- Middle is often filler, navigation links, related posts

**Example:**
```
Original (5000 chars):
"Every Diwali, my grandmother would make chakli...
[2000 chars of detailed recipe history]...
[1000 chars of related posts and navigation]...
The smell of chakli still takes me back to childhood."

Truncated (2000 chars):
"Every Diwali, my grandmother would make chakli...
[first 1000 chars]

[...]

The smell of chakli still takes me back to childhood.
[last 1000 chars]"
```

---

## Complete Example: Bundelkhand Food Blog

**Input text (truncated):**
```
Bundelkhand (बुन्देलखण्ड)… region located nearly at center of heartland
of India…Where I was born and brought-up.

Long ago someone sent me this small poem which was related to Bundelkhand
marriage ceremony and it touched me very deeply:

कहाँ गये वे कुँवर कलेऊ
दोना पातर कहाँ गये

Sannata is a thin, runny, sour/tangy buttermilk with spices including
black salt and bundi, traditionally made thin due to poverty in the region.
```

**LLM Output:**
```json
{
  "food_items": [
    "Sannata",
    "buttermilk",
    "black salt",
    "bundi",
    "kulevu (morning breakfast)",
    "daal",
    "baati"
  ],
  "region_cuisine": "Bundelkhandi cuisine",
  "occasion": "marriage ceremony, everyday meals",
  "emotions": "nostalgia, sentimental attachment, longing for home, forgetfulness",
  "key_snippets": [
    "Sannata is a thin, runny, sour/tangy buttermilk with spices including black salt and bundi, traditionally made thin due to poverty in the region.",
    "The poem reflects the fading memory of Bundelkhandi marriage ceremonies and associated food traditions."
  ],
  "language_of_origin": "hi",
  "content_summary": "A nostalgic account of forgotten Bundelkhandi food traditions and recipes from the author's childhood."
}
```

---

## Complete Example: About Page (Personal Story)

**Input text:**
```
I'm Anita, a Maharashtrian who grew up in Bombay. I enjoyed cooking
even as a very young child and could make rotlis on my own by the time
I was 8. My favorite was bhinda (okra). Every recipe on this site
comes from my family kitchen in Pune.
```

**LLM Output:**
```json
{
  "food_items": ["rotlis", "bhinda", "okra"],
  "region_cuisine": "Maharashtrian (Bombay and Maharashtra) with influences from Gujarat",
  "occasion": "",
  "emotions": "pride, nostalgia, family warmth",
  "key_snippets": [
    "I enjoyed cooking even as a very young child and could make rotlis on my own by the time I was 8.",
    "My favorite was bhinda."
  ],
  "language_of_origin": "en",
  "content_summary": "Personal introduction of a Maharashtrian food blogger who grew up cooking in Bombay."
}
```

---

## Batch Processing

```python
def run_extraction_batch(pages):
    results = []
    
    for i, page in enumerate(pages, 1):
        print(f"[{i}/{len(pages)}] {page['url'][:80]}")
        
        result = extract_with_llm(page)
        
        if result:
            results.append(result)
            print(f"  ✓ {len(result['food_items'])} food items | {result['region_cuisine']}")
        else:
            print(f"  ✗ Skipped")
        
        time.sleep(3)  # 3 second delay between API calls
    
    return results
```

**Why 3 second delay?** Mistral's free tier allows ~1 request/second. 3 seconds gives comfortable headroom.

---

## Error Handling

### JSON Parse Error
Sometimes the LLM returns malformed JSON (rare but happens with very long or unusual text):

```python
try:
    extracted = json.loads(raw_output)
except json.JSONDecodeError as e:
    print(f"JSON parse error: {e}")
    return None  # skip this page
```

### Rate Limit (429)
```python
except Exception as e:
    if "429" in str(e) or "capacity" in str(e).lower():
        wait = 15 * attempt  # 15s, 30s, 45s
        time.sleep(wait)
        # retry...
```

### Markdown Code Fences
Sometimes the LLM wraps JSON in markdown despite instructions:
```
```json
{"food_items": [...]}
```
```

We strip these:
```python
if raw_output.startswith("```"):
    raw_output = re.sub(r"^```[a-z]*\n?", "", raw_output)
    raw_output = re.sub(r"\n?```$", "", raw_output).strip()
```

---

## What Gets Saved to MongoDB

```json
{
  "_id": "ObjectId(...)",
  "page_id": "ObjectId(...)",
  "url": "https://ashtiw.wordpress.com/bundelkhand-food-forgotten-recipes/",
  "page_type": "story",
  "language": "hi",
  "food_items": ["Sannata", "buttermilk", "black salt", "bundi", "daal", "baati"],
  "region_cuisine": "Bundelkhandi cuisine",
  "occasion": "marriage ceremony, everyday meals",
  "emotions": "nostalgia, sentimental attachment, longing for home",
  "key_snippets": [
    "Sannata is a thin, runny, sour/tangy buttermilk with spices...",
    "The poem reflects the fading memory of Bundelkhandi marriage ceremonies..."
  ],
  "raw_llm_output": "{...full JSON string...}",
  "extracted_at": "2026-05-09T17:20:00Z"
}
```

Note: `food_items` and `key_snippets` are stored as **native MongoDB arrays** — not JSON strings. This means you can query directly:

```javascript
// Find all extracts mentioning "biryani"
db.extracts.find({"food_items": "biryani"})

// Find all Hyderabadi food stories
db.extracts.find({"region_cuisine": /Hyderabadi/i, "page_type": "story"})
```
