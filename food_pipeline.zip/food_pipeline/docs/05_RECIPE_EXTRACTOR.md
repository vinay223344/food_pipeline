# recipe_extractor.py — Recipe Data Extraction

## What Does the Recipe Extractor Do?

For pages classified as `recipe`, this module extracts fully structured recipe data:
- Dish name
- Description
- Cuisine and region
- Ingredients (with quantities and units)
- Method steps (numbered)
- Prep time, cook time, total time
- Servings
- Occasion and dietary info

**Input:** Recipe page dict `{url, html, raw_text, title}`
**Output:** Structured recipe dict or `None` if extraction fails

---

## Dual Strategy: Library First, LLM Fallback

The extractor uses **two methods** in sequence:

```
HTML page
    │
    ▼
┌─────────────────────────────────┐
│  Method 1: recipe-scrapers      │
│  (library, schema-based)        │
│  Fast, free, very accurate      │
└──────────────┬──────────────────┘
               │
    ┌──────────┴──────────┐
    │ Schema found?        │
    ├──────────────────────┤
    │ YES → return result  │
    │ NO  → try Method 2   │
    └──────────────────────┘
               │
               ▼
┌─────────────────────────────────┐
│  Method 2: Mistral LLM          │
│  (AI, text-based)               │
│  Slower, costs API, handles     │
│  any unstructured recipe text   │
└─────────────────────────────────┘
```

---

## Method 1: recipe-scrapers Library

### What Is It?

`recipe-scrapers` is a Python library that knows how to extract recipe data from 500+ popular recipe websites. It looks for structured data embedded in the HTML — specifically **JSON-LD** and **microdata** schemas.

### What Is JSON-LD?

Many recipe websites embed machine-readable data in their HTML like this:

```html
<script type="application/ld+json">
{
  "@type": "Recipe",
  "name": "Maharashtrian Kanda Bhaji",
  "recipeIngredient": [
    "2 medium onions, sliced",
    "1 cup besan (gram flour)",
    "1 tsp salt",
    "1/4 tsp turmeric"
  ],
  "recipeInstructions": [
    {"text": "Slice onions thinly and salt them"},
    {"text": "Add besan and spices, mix well"},
    {"text": "Deep fry until golden"}
  ],
  "prepTime": "PT10M",
  "cookTime": "PT20M",
  "recipeYield": "4 servings"
}
</script>
```

The library reads this structured data directly — no guessing needed.

### How We Use It

```python
from recipe_scrapers import scrape_html

def extract_with_library(html, url):
    scraper = scrape_html(html, org_url=url, wild_mode=True)
    
    ingredients = scraper.ingredients()
    # → ["2 medium onions, sliced", "1 cup besan", ...]
    
    instructions = scraper.instructions_list()
    # → ["Slice onions thinly", "Add besan and spices", "Deep fry"]
    
    result = {
        "dish_name":   scraper.title(),
        "description": scraper.description(),
        "cuisine":     scraper.cuisine(),
        "ingredients": [{"item": ing} for ing in ingredients],
        "method":      instructions,
        "servings":    scraper.yields(),
        "prep_time":   scraper.prep_time(),
        "cook_time":   scraper.cook_time(),
        "total_time":  scraper.total_time(),
        "source":      "recipe-scrapers",
    }
    
    return result if result["dish_name"] and result["ingredients"] else None
```

### `wild_mode=True`

This tells the library to try extracting even from unsupported sites by looking for any recipe schema it can find. Without this, it would only work on its 500+ known sites.

### Real Output Example

```python
{
    "dish_name":   "Maharashtrian Kanda Bhaji",
    "description": "Crispy onion fritters from Maharashtra",
    "cuisine":     "Indian",
    "region":      "",
    "ingredients": [
        {"item": "2 medium onions (about 380g, sliced pole to pole)", "quantity": "", "unit": "", "notes": ""},
        {"item": "1 tsp salt (or to taste)",                          "quantity": "", "unit": "", "notes": ""},
        {"item": "1 green chili (finely chopped)",                    "quantity": "", "unit": "", "notes": ""},
        {"item": "1/4 cup cilantro (finely chopped)",                 "quantity": "", "unit": "", "notes": ""},
        {"item": "1/2 cup + 2 Tbsp besan (gram flour)",              "quantity": "", "unit": "", "notes": ""},
    ],
    "method": [
        "Slice and salt the onions: Slice onions thinly pole to pole. Add salt and massage...",
        "Add herbs and spices: Mix in the cilantro, green chili, turmeric...",
        "Add the flours: Add rice flour and mix. Gradually add besan...",
        "Fry: Heat oil in a pan over medium-high heat...",
    ],
    "servings":   "4 servings",
    "prep_time":  "10",
    "cook_time":  "20",
    "total_time": "30",
    "source":     "recipe-scrapers"
}
```

---

## Method 2: Mistral LLM Fallback

### When Is This Used?

- Site not in the library's 500+ supported list
- No JSON-LD or microdata schema found
- Schema found but incomplete

### The Prompt

```python
RECIPE_EXTRACTION_PROMPT = """
Extract the recipe information from the following text.

Text:
\"\"\"
{text}
\"\"\"

Return a JSON object with exactly these fields:
{
  "dish_name": "name of the dish",
  "description": "one sentence description",
  "cuisine": "cuisine type (e.g. Gujarati, Bengali, South Indian)",
  "region": "specific region or state if mentioned",
  "ingredients": [
    {"item": "ingredient name", "quantity": "amount", "unit": "unit", "notes": "prep notes"}
  ],
  "method": ["step 1", "step 2", "step 3"],
  "servings": "number of servings",
  "prep_time": "preparation time",
  "cook_time": "cooking time",
  "total_time": "total time",
  "occasion": "when this dish is typically made",
  "dietary": "vegetarian/vegan/non-vegetarian",
  "language_of_origin": "language the recipe was written in"
}
"""
```

### LLM Input Example

**Raw text from an unstructured blog:**
```
Meen Kuzhumbu is a traditional Tamil fish curry. You'll need:
- 500g fish (any firm fish)
- 2 tbsp sesame oil
- 1 tsp mustard seeds
- 10 curry leaves
- 2 tomatoes, chopped
- 2 tbsp tamarind paste
- 1 tsp red chili powder
- 1/2 tsp turmeric

Heat oil, add mustard seeds. When they splutter, add curry leaves.
Add tomatoes and cook till soft. Add tamarind, chili powder, turmeric.
Add fish and cook for 15 minutes. Serve with rice.
```

### LLM Output Example

```json
{
  "dish_name": "Meen Kuzhumbu",
  "description": "Traditional Tamil fish curry with tamarind and spices",
  "cuisine": "Tamil",
  "region": "Tamil Nadu",
  "ingredients": [
    {"item": "fish", "quantity": "500", "unit": "g", "notes": "any firm fish"},
    {"item": "sesame oil", "quantity": "2", "unit": "tbsp", "notes": ""},
    {"item": "mustard seeds", "quantity": "1", "unit": "tsp", "notes": ""},
    {"item": "curry leaves", "quantity": "10", "unit": "whole", "notes": ""},
    {"item": "tomatoes", "quantity": "2", "unit": "whole", "notes": "chopped"},
    {"item": "tamarind paste", "quantity": "2", "unit": "tbsp", "notes": ""},
    {"item": "red chili powder", "quantity": "1", "unit": "tsp", "notes": ""},
    {"item": "turmeric", "quantity": "0.5", "unit": "tsp", "notes": ""}
  ],
  "method": [
    "Heat oil in a pan, add mustard seeds",
    "When mustard seeds splutter, add curry leaves",
    "Add tomatoes and cook until soft",
    "Add tamarind paste, chili powder, and turmeric",
    "Add fish pieces and cook for 15 minutes",
    "Serve hot with rice"
  ],
  "servings": "4",
  "prep_time": "10",
  "cook_time": "20",
  "total_time": "30",
  "occasion": "everyday meal",
  "dietary": "non-vegetarian",
  "language_of_origin": "en"
}
```

---

## Rate Limit Handling

Mistral's free tier has rate limits. If we hit them:

```python
for attempt in range(1, 4):  # try 3 times
    try:
        response = client.chat.complete(...)
        return parse_response(response)
    
    except Exception as e:
        if "429" in str(e):  # rate limited
            wait = 15 * attempt  # 15s, 30s, 45s
            print(f"Rate limited. Waiting {wait}s...")
            time.sleep(wait)
        else:
            return None  # other error, give up
```

**Backoff schedule:**
```
Attempt 1 fails → wait 15 seconds → retry
Attempt 2 fails → wait 30 seconds → retry
Attempt 3 fails → wait 45 seconds → give up, return None
```

---

## Pipeline Log Output

```
[Recipe Extractor] Processing 19 recipe pages...
  [001/19] https://indiaphile.info/kanda-bhaji/
           ✓ [library] Maharashtrian Kanda Bhaji | 10 ingredients | 6 steps
  [002/19] https://indiaphile.info/bhuna-gosht/
           ✓ [library] Bhuna Gosht | 20 ingredients | 6 steps
  [003/19] https://gitaskitchen.blogspot.com/meen-kuzhumbu.html
           ✓ [llm] Meen Kuzhumbu | 8 ingredients | 6 steps
  [004/19] https://gitaskitchen.blogspot.com/unknown-recipe.html
           ✗ Could not extract recipe

[Recipe Extractor] Done. 18/19 recipes extracted.
```

- `[library]` = extracted by recipe-scrapers (fast, free)
- `[llm]` = extracted by Mistral (slower, costs API)
- `✗` = both methods failed (very rare)

---

## What Gets Saved to MongoDB

Each recipe becomes one document in the `recipes` collection:

```json
{
  "_id": "ObjectId(...)",
  "page_id": "ObjectId(...)",
  "url": "https://indiaphile.info/kanda-bhaji/",
  "source_site": "indiaphile.info",
  "language": "en",
  "dish_name": "Maharashtrian Kanda Bhaji",
  "cuisine": "Indian",
  "region": "",
  "ingredients": [...],
  "method": [...],
  "servings": "4 servings",
  "prep_time": "10",
  "cook_time": "20",
  "total_time": "30",
  "extraction_source": "recipe-scrapers",
  "extracted_at": "2026-05-09T17:15:00Z"
}
```
