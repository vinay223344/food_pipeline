# crawler.py — Web Crawler

## What Does the Crawler Do?

The crawler takes a single starting URL (called the **seed URL**) and automatically discovers and downloads every page on that website by following links — just like a search engine spider.

**Input:** One URL (e.g., `https://indiaphile.info/posts/`)
**Output:** A list of pages, each containing `{url, html, title}`

---

## How It Works — Step by Step

### Step 1: Start with the Seed URL

```python
crawl("https://indiaphile.info/posts/", depth=2)
```

The crawler puts the seed URL in a queue with depth=0:
```
Queue: [("https://indiaphile.info/posts/", depth=0)]
Visited: {}
Results: []
```

---

### Step 2: BFS (Breadth-First Search)

The crawler uses **BFS** — it processes all pages at depth 1 before going to depth 2. This ensures we get the most important pages first.

```
Depth 0:  https://indiaphile.info/posts/
           ↓ links found on this page
Depth 1:  /kanda-bhaji/  /bhuna-gosht/  /about/  /region/gujarat/
           ↓ links found on depth-1 pages
Depth 2:  /related-recipe-1/  /related-recipe-2/  ...
```

---

### Step 3: For Each URL in the Queue

```python
while queue is not empty AND len(results) < MAX_PAGES:
    url, current_depth = queue.pop(0)  # take from front (BFS)
    
    if url already in visited:
        skip  # don't process same URL twice
    
    visited.add(url)
    html = fetch_page(url)
    
    if html:
        results.append({url, html, title})
        
        if current_depth < max_depth:
            links = extract_links(html, url)
            for link in links:
                queue.append((link, current_depth + 1))
    
    sleep(1.5)  # rate limit
```

---

### Step 4: Fetching a Page

```python
def fetch_page(url):
    response = requests.get(url, headers=REQUEST_HEADERS, timeout=15)
    
    if response.status_code == 200 and "text/html" in Content-Type:
        return response.text, response.url
    else:
        return None, None
```

**What can go wrong:**
- `404 Not Found` → page doesn't exist → skip
- `403 Forbidden` → site blocked us → skip
- `Timeout` → site too slow → skip
- `Not text/html` → it's a PDF or image → skip

---

### Step 5: URL Normalization

Before adding a URL to the visited set, we normalize it to avoid duplicates:

```python
def normalize_url(base, href):
    url = urljoin(base, href)      # make absolute
    url = remove_fragment(url)     # remove #section
    url = url.rstrip("/")          # remove trailing slash
    return url
```

**Example:**
```
Raw href:    "/kanda-bhaji/"
Base URL:    "https://indiaphile.info/posts/"
After join:  "https://indiaphile.info/kanda-bhaji/"
After norm:  "https://indiaphile.info/kanda-bhaji"

These are all the same page — normalized to one:
https://indiaphile.info/kanda-bhaji/
https://indiaphile.info/kanda-bhaji
https://indiaphile.info/kanda-bhaji#comments
→ All become: "https://indiaphile.info/kanda-bhaji"
```

---

### Step 6: Link Extraction

```python
def extract_links(html, base_url):
    soup = BeautifulSoup(html, "lxml")
    links = set()
    
    for tag in soup.find_all("a", href=True):
        href = tag["href"]
        full_url = normalize_url(base_url, href)
        
        if is_same_domain(base_url, full_url):  # stay on same site
            if not should_skip(full_url):        # not a noise page
                links.add(full_url)
    
    return links
```

**Same domain check:**
```
Base: https://indiaphile.info/posts/
Link: https://indiaphile.info/kanda-bhaji/  → SAME DOMAIN ✓
Link: https://google.com/                   → DIFFERENT DOMAIN ✗
Link: https://facebook.com/share/...        → DIFFERENT DOMAIN ✗
```

---

### Step 7: URL Skip Rules

```python
def should_skip(url):
    # Skip by file extension
    skip_extensions = [".jpg", ".png", ".pdf", ".mp4", ".css", ".js"]
    if url ends with any skip_extension:
        return True
    
    # Skip noise pages
    skip_patterns = ["privacy", "login", "sitemap", "contact", ...]
    if any pattern in url path:
        return True
    
    return False
```

**Examples:**
```
https://indiaphile.info/images/kanda-bhaji.jpg  → SKIP (.jpg)
https://indiaphile.info/privacy-policy/         → SKIP (privacy)
https://indiaphile.info/wp-admin/               → SKIP (wp-admin)
https://indiaphile.info/kanda-bhaji/            → CRAWL ✓
```

---

## Real Example: Crawling indiaphile.info

```
[Crawler] Starting crawl: https://indiaphile.info/posts/
[Crawler] Max depth=1, Max pages=100

[001] depth=0 | https://indiaphile.info/posts/
[002] depth=1 | https://indiaphile.info/kanda-bhaji
[003] depth=1 | https://indiaphile.info/bhuna-gosht
[004] depth=1 | https://indiaphile.info/surti-undhiyu
[005] depth=1 | https://indiaphile.info/region/gujarat
...
[024] depth=1 | https://indiaphile.info/payasam

[Crawler] Done. Collected 24 pages.
```

Notice: `privacy-policy` is NOT in the list — it was skipped by the URL filter.

---

## Output Format

Each crawled page is a Python dictionary:

```python
{
    "url":   "https://indiaphile.info/kanda-bhaji/",
    "html":  "<!DOCTYPE html><html>...(full HTML)...</html>",
    "title": "Maharashtrian Kanda Bhaji | Indiaphile"
}
```

This gets passed to the **Extractor** in the next stage.

---

## Edge Cases Handled

| Situation | How Handled |
|---|---|
| Same URL linked multiple times | `visited` set prevents re-processing |
| Relative URLs (`/about/`) | `urljoin()` converts to absolute |
| Redirect (301/302) | `requests` follows automatically, stores final URL |
| Timeout | Caught, page skipped, crawl continues |
| Non-HTML response | Checked via `Content-Type` header |
| Infinite link loops | `visited` set breaks the loop |
| Too many pages | `MAX_PAGES` cap stops the crawl |

---

## Configuration

All crawler settings are in `config.py`:

```python
CRAWL_DEPTH        = 3     # change to go deeper
MAX_PAGES          = 100   # change to crawl more pages
RATE_LIMIT_SECONDS = 1.5   # change to crawl faster (risky)
REQUEST_TIMEOUT    = 15    # change if site is slow
```

You can also override `MAX_PAGES` from the UI slider or `--depth` CLI flag.
