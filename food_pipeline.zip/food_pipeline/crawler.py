# crawler.py — Recursive web crawler

import requests
import time
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from config import CRAWL_DEPTH, MAX_PAGES, RATE_LIMIT_SECONDS, REQUEST_TIMEOUT, REQUEST_HEADERS, SKIP_URL_PATTERNS


def is_same_domain(base_url, link):
    """Check if a link belongs to the same domain as the base URL."""
    base_domain = urlparse(base_url).netloc
    link_domain = urlparse(link).netloc
    return link_domain == base_domain or link_domain == ""


def normalize_url(base, href):
    """Convert relative URLs to absolute."""
    url = urljoin(base, href)
    parsed = urlparse(url)
    clean = parsed._replace(fragment="").geturl()
    return clean.rstrip("/")


def should_skip(url):
    """Skip non-content URLs — media files, admin pages, noise pages."""
    skip_extensions = (".jpg", ".jpeg", ".png", ".gif", ".svg", ".pdf",
                       ".zip", ".mp3", ".mp4", ".css", ".js", ".xml", ".ico")
    url_lower = url.lower()

    # Skip by file extension
    if any(url_lower.endswith(ext) for ext in skip_extensions):
        return True

    # Skip by URL pattern (noise pages like privacy, about, login, etc.)
    path = urlparse(url).path.lower()
    if any(pat in path for pat in SKIP_URL_PATTERNS):
        return True

    # Skip technical patterns
    tech_patterns = ["mailto:", "javascript:", "tel:", "#", "wp-login",
                     "wp-admin", "feed", "comment"]
    if any(pat in url_lower for pat in tech_patterns):
        return True

    return False


def fetch_page(url):
    """Fetch a single URL and return (html, final_url) or (None, None) on failure."""
    try:
        resp = requests.get(url, headers=REQUEST_HEADERS, timeout=REQUEST_TIMEOUT)
        if resp.status_code == 200 and "text/html" in resp.headers.get("Content-Type", ""):
            return resp.text, resp.url
        else:
            print(f"  [SKIP] {url} — status {resp.status_code}")
            return None, None
    except Exception as e:
        print(f"  [ERROR] {url} — {e}")
        return None, None


def extract_links(html, base_url):
    """Extract all internal links from a page."""
    soup = BeautifulSoup(html, "lxml")
    links = set()
    for tag in soup.find_all("a", href=True):
        href = tag["href"].strip()
        if not href:
            continue
        full_url = normalize_url(base_url, href)
        if is_same_domain(base_url, full_url) and not should_skip(full_url):
            links.add(full_url)
    return links


def crawl(seed_url, depth=CRAWL_DEPTH, max_pages=MAX_PAGES):
    """
    Crawl a website starting from seed_url.
    Returns a list of dicts: {url, html, title}
    """
    visited   = set()
    to_visit  = [(seed_url, 0)]   # (url, current_depth)
    results   = []

    print(f"\n[Crawler] Starting crawl: {seed_url}")
    print(f"[Crawler] Max depth={depth}, Max pages={max_pages}\n")

    while to_visit and len(results) < max_pages:
        url, current_depth = to_visit.pop(0)

        # Normalize for dedup
        clean = normalize_url(seed_url, url)
        if clean in visited:
            continue
        visited.add(clean)

        print(f"  [{len(results)+1:03d}] depth={current_depth} | {url}")

        html, final_url = fetch_page(url)
        if not html:
            time.sleep(RATE_LIMIT_SECONDS)
            continue

        # Parse title
        soup = BeautifulSoup(html, "lxml")
        title_tag = soup.find("title")
        title = title_tag.get_text(strip=True) if title_tag else ""

        results.append({
            "url":   final_url or url,
            "html":  html,
            "title": title,
        })

        # Queue child links if we haven't hit max depth
        if current_depth < depth:
            links = extract_links(html, final_url or url)
            for link in links:
                norm = normalize_url(seed_url, link)
                if norm not in visited:
                    to_visit.append((link, current_depth + 1))

        time.sleep(RATE_LIMIT_SECONDS)

    print(f"\n[Crawler] Done. Collected {len(results)} pages.")
    return results
