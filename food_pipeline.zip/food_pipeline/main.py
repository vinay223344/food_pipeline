# main.py — Entry point for the Indian Food Data Mining Pipeline
#
# Usage:
#   python main.py --url https://indiaphile.info/posts/ --depth 2
#   python main.py --url https://indiaphile.info/posts/ --depth 2 --no-llm
#   python main.py --stats
#   python main.py --export

import argparse
import sys
from urllib.parse import urlparse

from crawler       import crawl
from extractor     import process_page
from classifier    import classify_page
from llm_extractor import run_extraction_batch
from recipe_extractor import run_recipe_extraction_batch


def get_site_name(url):
    return urlparse(url).netloc


def load_storage(use_mongo=False):
    """Return the correct storage module based on flag."""
    if use_mongo:
        import storage_mongo as store
    else:
        import storage as store
    return store


def run_pipeline(seed_url, depth, run_llm=True, use_mongo=False):
    """Full pipeline: crawl → extract → classify → LLM → store."""

    print("\n" + "="*60)
    print("  INDIAN FOOD DATA MINING PIPELINE")
    print(f"  Storage: {'MongoDB' if use_mongo else 'SQLite'}")
    print("="*60)

    store = load_storage(use_mongo)
    store.init_db()

    # ── Stage 1: Crawl ────────────────────────────────────────────
    print("\n[Stage 1] CRAWLING...")
    pages = crawl(seed_url, depth=depth)

    if not pages:
        print("[ERROR] No pages crawled. Check the URL and try again.")
        sys.exit(1)

    # ── Stage 2 & 3: Extract text + Classify ─────────────────────
    print(f"\n[Stage 2+3] EXTRACTING TEXT & CLASSIFYING {len(pages)} pages...")
    site_name = get_site_name(seed_url)
    processed = []

    for page in pages:
        p = process_page(page)

        if not p["is_food"]:
            print(f"  [SKIP] Not food-related: {p['url'][:70]}")
            continue

        p = classify_page(p)
        processed.append(p)

        # Save to DB and capture the assigned page_id
        db_id = store.save_page(
            url        = p["url"],
            title      = p["title"],
            raw_text   = p["raw_text"],
            language   = p["language"],
            page_type  = p["page_type"],
            source_site= site_name,
        )
        p["id"] = db_id  # attach DB id so LLM extractor can reference it
        print(f"  [SAVED] [{p['page_type']:12s}] [{p['language']:5s}] {p['url'][:65]}")

    print(f"\n  → {len(processed)} food-related pages saved to DB.")

    # ── Stage 4a: Recipe Extraction ──────────────────────────────
    if run_llm:
        print("\n[Stage 4a] RECIPE EXTRACTION...")
        recipe_pages = [p for p in processed if p["page_type"] == "recipe"]

        if not recipe_pages:
            print("  No recipe pages found.")
        else:
            # Attach html back to processed pages for recipe-scrapers library
            html_map = {pg["url"].rstrip("/"): pg["html"] for pg in pages}
            for p in recipe_pages:
                p["html"] = html_map.get(p["url"].rstrip("/"), "")

            recipe_results = run_recipe_extraction_batch(recipe_pages)

            for page, recipe in recipe_results:
                store.save_recipe(
                    page_id     = page.get("id"),
                    url         = page["url"],
                    source_site = site_name,
                    language    = page.get("language", "unknown"),
                    recipe_data = recipe,
                )
            print(f"\n  → {len(recipe_results)} recipes saved to DB.")

    # ── Stage 4b: Non-recipe LLM Extraction ──────────────────────
        print("\n[Stage 4b] NON-RECIPE LLM EXTRACTION (stories, experiences, reviews)...")
        non_recipe = [p for p in processed if p["page_type"] not in ("recipe", "other")]

        if not non_recipe:
            print("  No non-recipe pages to extract from.")
        else:
            results = run_extraction_batch(non_recipe)

            # Save extracts to DB
            for r in results:
                store.save_extract(
                    page_id       = r["page_id"],
                    url           = r["url"],
                    page_type     = r["page_type"],
                    language      = r["language"],
                    food_items    = r["food_items"],
                    region_cuisine= r["region_cuisine"],
                    occasion      = r["occasion"],
                    emotions      = r["emotions"],
                    key_snippets  = r["key_snippets"],
                    raw_llm_output= r["raw_llm_output"],
                )
            print(f"\n  → {len(results)} extracts saved to DB.")
    else:
        print("\n[Stage 4] LLM extraction skipped (--no-llm flag).")

    # ── Stage 5: Summary ──────────────────────────────────────────
    print("\n[Stage 5] SUMMARY")
    store.get_stats()

    # Auto-export CSV
    store.export_to_csv()
    db_label = "MongoDB: indian_food_db" if use_mongo else "SQLite: data/food_data.db"
    csv_label = "data/extracts_export_mongo.csv" if use_mongo else "data/extracts_export.csv"
    print("\n[DONE] Pipeline complete.")
    print(f"  Database : {db_label}")
    print(f"  CSV      : {csv_label}")


def main():
    parser = argparse.ArgumentParser(
        description="Indian Food Data Mining Pipeline"
    )
    parser.add_argument("--url",    type=str, help="Seed URL to crawl")
    parser.add_argument("--depth",  type=int, default=2, help="Crawl depth (default: 2)")
    parser.add_argument("--no-llm", action="store_true", help="Skip LLM extraction")
    parser.add_argument("--mongo",  action="store_true", help="Use MongoDB instead of SQLite")
    parser.add_argument("--stats",  action="store_true", help="Show DB stats and exit")
    parser.add_argument("--export", action="store_true", help="Export DB to CSV and exit")

    args = parser.parse_args()

    # Load the right storage module
    store = load_storage(args.mongo)
    store.init_db()

    if args.stats:
        store.get_stats()
        return

    if args.export:
        store.export_to_csv()
        return

    if not args.url:
        print("Error: --url is required. Example:")
        print("  python main.py --url https://indiaphile.info/posts/ --depth 2 --mongo")
        sys.exit(1)

    run_pipeline(
        seed_url  = args.url,
        depth     = args.depth,
        run_llm   = not args.no_llm,
        use_mongo = args.mongo,
    )


if __name__ == "__main__":
    main()
