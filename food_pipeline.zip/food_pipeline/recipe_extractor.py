# recipe_extractor.py — Structured recipe extraction
#
# Strategy:
#   1. Try recipe-scrapers library (supports 500+ known sites) — fast, no LLM needed
#   2. If that fails, fall back to Mistral LLM extraction from raw text

import json
import re
import time
from recipe_scrapers import scrape_html, WebsiteNotImplementedError, NoSchemaFoundInWildMode
from mistralai import Mistral
from config import MISTRAL_API_KEY, MISTRAL_MODEL, RECIPE_LLM_MAX_CHARS

client = Mistral(api_key=MISTRAL_API_KEY)

# ── LLM prompt for recipe extraction ─────────────────────────────────────────

RECIPE_SYSTEM_PROMPT = """You are an expert at extracting structured recipe data from text.
You understand recipes in all Indian languages and cuisines.
Always respond with valid JSON only — no markdown, no explanation."""

RECIPE_EXTRACTION_PROMPT = """Extract the recipe information from the following text.

Text:
\"\"\"
{text}
\"\"\"

Return a JSON object with exactly these fields:
{{
  "dish_name": "name of the dish",
  "description": "one sentence description of the dish",
  "cuisine": "cuisine type (e.g. Gujarati, Bengali, South Indian, Pakistani, etc.)",
  "region": "specific region or state if mentioned",
  "ingredients": [
    {{"item": "ingredient name", "quantity": "amount", "unit": "unit of measurement", "notes": "optional prep notes"}}
  ],
  "method": ["step 1", "step 2", "step 3"],
  "servings": "number of servings",
  "prep_time": "preparation time",
  "cook_time": "cooking time",
  "total_time": "total time",
  "occasion": "when this dish is typically made (e.g. festival, everyday, wedding)",
  "dietary": "dietary info (e.g. vegetarian, vegan, non-vegetarian)",
  "language_of_origin": "language the recipe was originally written in"
}}

Rules:
- ingredients must be a JSON array of objects
- method must be a JSON array of strings (one step per item)
- If a field has no information, use empty string "" or empty array []
- Respond with JSON only"""


def _safe_get(scraper, method_name, default=None):
    """Safely call a scraper method, returning default on any error."""
    try:
        val = getattr(scraper, method_name)()
        return val if val else default
    except Exception:
        return default


def extract_with_library(html, url):
    """
    Try recipe-scrapers library first.
    Returns structured dict or None if site not supported / no recipe found.
    """
    try:
        scraper = scrape_html(html, org_url=url, wild_mode=True)

        ingredients_raw = _safe_get(scraper, "ingredients", [])
        instructions_raw = _safe_get(scraper, "instructions_list", [])
        if not instructions_raw:
            # fallback: split instructions string by newline
            inst_str = _safe_get(scraper, "instructions", "")
            if inst_str:
                instructions_raw = [s.strip() for s in inst_str.split("\n") if s.strip()]

        # Build structured ingredients list
        ingredients = []
        for ing in (ingredients_raw or []):
            ingredients.append({
                "item":     ing,
                "quantity": "",
                "unit":     "",
                "notes":    "",
            })

        result = {
            "dish_name":   _safe_get(scraper, "title", ""),
            "description": _safe_get(scraper, "description", ""),
            "cuisine":     _safe_get(scraper, "cuisine", ""),
            "region":      "",
            "ingredients": ingredients,
            "method":      instructions_raw or [],
            "servings":    str(_safe_get(scraper, "yields", "")),
            "prep_time":   str(_safe_get(scraper, "prep_time", "")),
            "cook_time":   str(_safe_get(scraper, "cook_time", "")),
            "total_time":  str(_safe_get(scraper, "total_time", "")),
            "occasion":    "",
            "dietary":     "",
            "language_of_origin": "en",
            "source":      "recipe-scrapers",
        }

        # Only return if we got at least a title and some ingredients or steps
        if result["dish_name"] and (result["ingredients"] or result["method"]):
            return result
        return None

    except (WebsiteNotImplementedError, NoSchemaFoundInWildMode):
        return None
    except Exception:
        return None


def extract_with_llm(raw_text, url, retries=3, retry_delay=15):
    """
    LLM-based recipe extraction fallback using Mistral.
    Returns structured dict or None on failure.
    """
    if not raw_text or len(raw_text) < 100:
        return None

    # Truncate to fit token limits
    text_sample = raw_text[:RECIPE_LLM_MAX_CHARS] if len(raw_text) > RECIPE_LLM_MAX_CHARS else raw_text
    prompt = RECIPE_EXTRACTION_PROMPT.format(text=text_sample)

    for attempt in range(1, retries + 1):
        try:
            response = client.chat.complete(
                model=MISTRAL_MODEL,
                messages=[
                    {"role": "system", "content": RECIPE_SYSTEM_PROMPT},
                    {"role": "user",   "content": prompt},
                ],
                temperature=0.1,
                max_tokens=1200,
            )

            raw_output = response.choices[0].message.content.strip()

            # Strip markdown fences if present
            if raw_output.startswith("```"):
                raw_output = re.sub(r"^```[a-z]*\n?", "", raw_output)
                raw_output = re.sub(r"\n?```$", "", raw_output).strip()

            extracted = json.loads(raw_output)

            # Normalize fields
            ingredients = extracted.get("ingredients", [])
            if isinstance(ingredients, list):
                # Ensure each ingredient is a dict
                normalized = []
                for ing in ingredients:
                    if isinstance(ing, dict):
                        normalized.append(ing)
                    elif isinstance(ing, str):
                        normalized.append({"item": ing, "quantity": "", "unit": "", "notes": ""})
                ingredients = normalized

            method = extracted.get("method", [])
            if isinstance(method, str):
                method = [s.strip() for s in method.split("\n") if s.strip()]

            extracted["ingredients"] = ingredients
            extracted["method"]      = method
            extracted["source"]      = "llm"
            return extracted

        except json.JSONDecodeError as e:
            print(f"  [Recipe LLM] JSON parse error for {url}: {e}")
            return None
        except Exception as e:
            err_str = str(e)
            if "429" in err_str or "capacity" in err_str.lower():
                wait = retry_delay * attempt
                print(f"  [Recipe LLM] Rate limited (attempt {attempt}/{retries}). Waiting {wait}s...")
                time.sleep(wait)
            else:
                print(f"  [Recipe LLM] API error for {url}: {e}")
                return None

    return None


def extract_recipe(page):
    """
    Main entry point. Tries library first, then LLM.
    Input : page dict with keys: url, html, raw_text, title, id, language
    Output: structured recipe dict or None
    """
    url      = page.get("url", "")
    html     = page.get("html", "")
    raw_text = page.get("raw_text", "")

    # Try library first (fast, no API cost)
    result = None
    if html:
        result = extract_with_library(html, url)
        if result:
            print(f"         ✓ [library] {result['dish_name']} | "
                  f"{len(result['ingredients'])} ingredients | "
                  f"{len(result['method'])} steps")
            return result

    # Fall back to LLM
    result = extract_with_llm(raw_text, url)
    if result:
        print(f"         ✓ [llm] {result.get('dish_name','?')} | "
              f"{len(result.get('ingredients',[]))} ingredients | "
              f"{len(result.get('method',[]))} steps")
    else:
        print(f"         ✗ Could not extract recipe")

    return result


def run_recipe_extraction_batch(pages):
    """
    Run recipe extraction on a list of recipe pages.
    Returns list of (page, recipe_dict) tuples for successful extractions.
    """
    results = []
    total   = len(pages)

    print(f"\n[Recipe Extractor] Processing {total} recipe pages...")

    for i, page in enumerate(pages, 1):
        print(f"  [{i:03d}/{total}] {page['url'][:75]}")
        recipe = extract_recipe(page)
        if recipe:
            results.append((page, recipe))

        # Polite delay between LLM calls
        if i < total:
            time.sleep(2)

    print(f"\n[Recipe Extractor] Done. {len(results)}/{total} recipes extracted.")
    return results
